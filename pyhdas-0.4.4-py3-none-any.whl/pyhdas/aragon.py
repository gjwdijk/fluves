# Copyright (C) 2019 Fluves - All Rights Reserved

import io
import logging
from datetime import timezone
from math import ceil
from pathlib import Path

import numpy as np
import pandas as pd
import pkg_resources
import xarray as xr
import zstandard as zstd

from .denoise import denoise_matrix
from .utils import get_spatial_vec, utc_timestamp_to_datetime

logger = logging.getLogger(__name__)

# Header 102 (ID 101) defines the file type of aragon
FILE_TYPE_MAPPING = {
    0: "HDAS_2DRawData_Strain",
    1: "HDAS_2DRawData_Temp",
    2: "HDAS_2Dmap_Strain",
    3: "HDAS_2Dmap_Temp",
    4: "HDAS_FiberTrace",
    5: "HDAS_MultiPointStrain",
    6: "HDAS_MultiPointTemp",
    7: "HDAS_LaserRef_Strain",
    8: "HDAS_LaserRef_Temp",
    11: "HDAS_2Dmap_Energy",
}


class BinFileException(Exception):
    """Aragon Bin file can not be serialized."""


def get_header_dict():
    """Get Aragon provided header definition"""
    stream = pkg_resources.resource_stream(
        __name__, "data/aragon_header_description.csv"
    )
    header = pd.read_csv(stream, sep=";", header=None, names=["ID", "dummy", "Name"])
    header["ID"] = header["ID"].str.split(" ").str.get(1).astype(int) - 1
    header = header.set_index("ID")
    return header["Name"].to_dict()


def aragon_select_files(data_folder, start_date, end_date, extension="h5"):
    """Extract a subset of files in a folder based on dates

    Generator to provide aragon type files.

    Parameters
    ----------
    data_folder : Path
        Path to folder with data
    start_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    extension : h5 | bin | zst
        select the original binary files, zst or the hdf5 version
    """

    for filename in sorted(data_folder.rglob(f"*_HDAS*.{extension}")):
        datetime_file = pd.to_datetime(
            filename.name[:20], format="%Y_%m_%d_%Hh%Mm%Ss"
        ).tz_localize("UTC")
        if start_date - pd.Timedelta(61, unit="s") <= datetime_file <= end_date:
            yield filename
        else:
            continue


def aragon_load_data(bin_file, cable_range=None):
    """Load any bin file created by aragon DAS equipment

    Parameters
    ----------
    bin_file : Path | str
        Raw Aragon bin file to read
    cable_range : tuple of int (min, max)
        Provide a cable range to extract from the data using the start and end point
        in meter

    Returns
    -------
    xr_data : xarray Dataset
    """
    with AragonBinFile(bin_file, "rb") as aragon_bin:
        aragon = Aragon.load(aragon_bin, cable_range)
    return aragon.xr_data


def concat_raw_data(
    file_list, scale_factor="from_settings", cable_range=None, *args, **kwargs
):
    """Concatenate raw strain/temp files

    Concatenate and denoise raw strain or temperature files, compensating the reset
    of the data on each new file.

    Parameters
    ----------
    file_list : list of pathlib.Path
        The set of files to concatenate and do analysis on
    scale_factor : float or "from_settings"
        Scaling factor as provided by the Aragon Photonics. This scale factor is
        dependent on the device and resulting from the lab calibration from Aragon.
    cable_range : tuple of int (min, max)
        Provide a cable range to extract from the data using the start and end point
        in meter.
    *args, **kwargs :
        Parameters are passed to the aragon :py:meth:`pyhdas.denoise.denoise` function.

    Notes
    -----
    When a cable range is sliced, the initial load from the bin file wil include the
    reference fiber positions as well to denoise the data. After denoising, the
    result is sliced to the given cable_range slice to return only the requested range.

    Returns
    --------
    xr_data: xarray
    """
    data = []
    for j, file in enumerate(file_list):
        with AragonBinFile(file) as bin_file:
            if bin_file.file_type not in [
                "HDAS_2DRawData_Strain",
                "HDAS_2DRawData_Temp",
            ]:
                raise TypeError(
                    "Input files need to be raw strain or raw temperature data."
                )
            # cable_range includes ref-fiber as well to do denoising
            aragon = Aragon.load(bin_file, cable_range)
            aragon.denoise(scale_factor=scale_factor, *args, **kwargs)
            aragon.xr_data = aragon.xr_data.drop_vars(aragon.variable_name)
            denoised_variable = aragon.variable_name.replace("raw", "")

            # extract cable_range ignoring the ref-fiber after denoising
            if cable_range:
                aragon.xr_data = aragon.slice_cable(aragon.xr_data, cable_range)

        # adjust the resetting of the strain
        if j > 0:
            aragon.xr_data[denoised_variable] = (
                aragon.xr_data[denoised_variable]
                + data[j - 1][denoised_variable].isel(time=-1)
                - aragon.xr_data[denoised_variable].isel(time=0)
            )
        data.append(aragon.xr_data)

    xr_data = xr.concat(data, dim="time").sortby("time")
    del data

    return xr_data


class AragonBinFile:
    """Class representation of Aragon bin files

    Defined as a context manager, use it with `with` operator!

    Examples
    --------
    >>> bin_file = Path("my_aragon_bin_file")
    >>> with AragonBinFile(bin_file, "rb") as aragon_bin:
    >>>     aragon = Aragon.load(aragon_bin)
    """

    dt_header = np.dtype("<f8")

    def __init__(self, file_name, mode="rb"):
        """Load bin file from file without loading data itself.

        Parameters
        ----------
        file_name : str | Path
            File path of Aragon bin file.
        mode : str, default 'rb'
            Buffer mode to open file (r, w, rb,...)
        """
        self._filename = Path(file_name)
        self._compression = self._compression_from_suffix(self._filename)
        self.file_obj = self._buffer(self._filename, mode)

        # Read the header length
        self.file_obj.seek(0)  # making sure of the start position
        self._file_header_size = int(
            np.frombuffer(self.file_obj.read(8), dtype=self.dt_header, count=1)
        )  # First read the number of headers

        if not self._file_header_size > 101:
            raise BinFileException("Bin File does not have a valid header.")

        # read the entire header from the start
        self.file_obj.seek(0)
        self.header = np.frombuffer(
            self.file_obj.read(8 * self._file_header_size),
            dtype=self.dt_header,
            count=self._file_header_size,
        ).copy()

        self._file_type = FILE_TYPE_MAPPING[int(self.header[101])]

    @staticmethod
    def _compression_from_suffix(file_name):
        """Get the compression type from file name suffix.

        Parameters
        ----------
        file_name : Path
            File path
        """
        if file_name.suffix == ".bin":
            return None
        elif file_name.suffix == ".zst":
            return ".zst"
        else:
            raise BinFileException(
                f"{file_name.suffix} is not a " f"supported compression file format."
            )

    def _buffer(self, file_name, mode):
        """Return data as buffer.

        Either from a bin file or buffered stream from zstandard decrompession
        of a bin file.

        Parameters
        ----------
        file_name : Path
            File path of (compressed) aragon bin file
        mode : str, default 'rb'
            Buffer mode to open file (r, w, rb,...)
        """
        file_io = open(file_name, mode)
        if self._compression == ".zst":
            dctx = zstd.ZstdDecompressor()
            reader = dctx.stream_reader(file_io)
            return io.BytesIO(reader.read())
        else:
            return file_io

    @property
    def compression(self):
        """Property if file is compressed."""
        return self._compression

    @property
    def file_name(self):
        """Return the file name from which the the object is created"""
        return self._filename

    @property
    def header_dict(self):
        """Dict version of the header"""
        return {
            value: self.header[key]
            for (key, value) in get_header_dict().items()
            if value != "Empty"
        }

    @property
    def file_type(self):
        """Property with file type."""
        return self._file_type

    @property
    def file_header_size(self):
        """Property of file header size in bytes."""
        return self._file_header_size

    def __enter__(self):
        """Return object itslef in context manager."""
        # TODO - switch to method where the file object it contains can be closed;
        # not as context manager itself
        return self

    def __exit__(self, type, value, traceback):
        """Close file object to bin file."""
        self.file_obj.close()


class Aragon:
    """Factory to handle the different Aragon HDAS formats

    Parameters
    ----------
    aragon_bin : AragonBinFile
    cable_range : tuple of int (min, max)
        Provide a cable range to extract from the data using the start and end point
        in meter.

    Notes
    -----
    When selecting raw data (strain, temp), the cable range slice will not affect the
    loading of the reference fiber, as this section is required for the denoising.

    See also
    --------
    https://realpython.com/factory-method-python/
    https://medium.com/@vadimpushtaev/python-choosing-subclass-cf5b1b67c696
    """

    subclasses = {}
    dt = None
    variable_name = None

    def __init__(self, aragon_bin, cable_range=None):
        """Serialize Aragon bin file data returning proper class.

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        self.bin_file = aragon_bin
        self.xr_data = self.serialize(cable_range)

    def __repr__(self):
        """Represent as xarray wrapper."""
        return (
            f"Aragon class representation of {self.file_type} file, \n"
            f"with {self.xr_data.data_vars} \n"
            f"and {self.xr_data.coords}"
        )

    def __str__(self):
        """Print as xarray wrapper."""
        return (
            f"Aragon {self.file_type} data, \n"
            f"with {self.xr_data.data_vars} \n"
            f"and {self.xr_data.coords}"
        )

    @property
    def file_type(self):
        """Property with file type."""
        return self.bin_file.file_type

    @property
    def header(self):
        """Property with bin file header as array."""
        return self.bin_file.header

    @classmethod
    def register_subclass(cls, file_type):
        """Register the different aragon data type subclasses."""

        def decorator(subclass):
            """Return subclass"""
            cls.subclasses[file_type] = subclass
            return subclass

        return decorator

    @classmethod
    def load(cls, aragon, cable_range=None):
        """Factory method returning the proper subclass"""
        if aragon.file_type not in cls.subclasses:
            raise ValueError("Unsupported file type {}".format(aragon.file_type))
        return cls.subclasses[aragon.file_type](aragon, cable_range)

    def serialize(self, cable_range=None):
        """Method to overwrite in the subclasses

        Defines how to serialize the raw bin data into an xarray DataSet, which can be
        saved to netcdf directly.

        Parameters
        ----------
        cable_range : tuple of int (min, max), default None
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        return NotImplemented

    def to_h5(self, filename, *args, **kwargs):
        """Save the xarray dataset to a file

        Parameters
        ----------
        filename : str | Path
            File to write data to.
        *args, **kwargs :
            Passed to the xarray `to_netcdf` function.
        """
        # TODO - update functionality
        if self.xr_data:
            self.xr_data.to_netcdf(filename, *args, **kwargs)

    def _time_samples_from_file_size(self, n_processed_points):
        """Based on the file size specs, derive the number of processed time steps

        Parameters
        ----------
        n_processed_points : int
            Number of positions in the data set.
        """
        file_size = self.bin_file.file_name.stat().st_size
        n_time_samples = (
            (file_size - self.bin_file.file_header_size * 8)
            / self.dt.itemsize
            / n_processed_points
        )
        return int(n_time_samples)

    def _parse_2d_vector(self, n_processed_points):
        """Support function for reading the 2D data matrix

        When file is recording full minute, memmap can be used, otherwise the
        full file need to be read to know the file size

        Parameters
        ----------
        n_processed_points : int
            Number of positions in the data set.
        """
        # Start from beginning file again, (!) 'offset' in bytes, not 'dtype'
        self.bin_file.file_obj.seek(0, 0)

        if self.bin_file.compression:
            # compression - read data from buffer into memory
            traces_matrix = np.frombuffer(
                self.bin_file.file_obj.read(),
                dtype=self.dt,
                count=-1,
                offset=self.bin_file.file_header_size * 8,
            )
            n_time_samples = traces_matrix.size // n_processed_points
            traces_matrix = np.reshape(
                traces_matrix, (n_time_samples, n_processed_points)
            )
        else:
            n_time_samples = self._time_samples_from_file_size(n_processed_points)

            # no compression; memory map of the file
            traces_matrix = np.memmap(
                self.bin_file.file_obj,
                dtype=self.dt,
                mode="r",
                offset=self.bin_file.file_header_size * 8,
                shape=(n_time_samples, n_processed_points),
            )
        return traces_matrix, n_time_samples

    def slice_cable(self, xr_data, cable_range: tuple, ignore_ref_fiber=True):
        """Slice the data for a subset of positions

        Parameters
        ----------
        xr_data : xarray.DataSet
            Data set with a 'position' dimension.
        cable_range : tuple of int (min, max), default None
            Provide a cable range to extract from the data using the start and end point
            in meter.
        ignore_ref_fiber : boolean, default True
            If True, do not include the reference fiber when slicing the cable section.
        """
        min_range, max_range = cable_range
        if max_range < min_range:
            raise BinFileException(
                "Can not extract cable range with max < min of range."
            )
        # if both ranges are outside the xarray object position range, return error
        # Note: the slice can be too broad, but this is not an issue as long as any
        # value can be returned.
        if (
            min_range < xr_data.position.values.min()
            and max_range < xr_data.position.values.min()
        ) or (
            min_range > xr_data.position.values.max()
            and max_range > xr_data.position.values.max()
        ):
            raise BinFileException(
                "Can not extract cable range both min and max range outside cable range"
            )
        xr_data.position.values.max()

        # Handle ref fiber when slicing cable
        if not ignore_ref_fiber:
            ref_start, ref_stop = (
                self.bin_file.header_dict[
                    "Global_TimeProcessing_Strain_Start_Point_Laser_Denoising_(meters)"
                ],
                self.bin_file.header_dict[
                    "Global_TimeProcessing_Strain_Stop_Point_Laser_Denoising_(meters)"
                ],
            )

            # no overlap
            if (min_range < ref_start and max_range < ref_start) or (
                min_range > ref_stop and max_range > ref_stop
            ):
                return xr.concat(
                    [
                        xr_data.sel(position=slice(ref_start, ref_stop)),
                        xr_data.sel(position=slice(*cable_range)),
                    ],
                    dim="position",
                ).sortby("position")
            else:
                sel_start, sel_stop = (
                    min(min_range, ref_start),
                    max(max_range, ref_stop),
                )
                return xr_data.sel(position=slice(sel_start, sel_stop))

        else:
            return xr_data.sel(position=slice(*cable_range))

    @staticmethod
    def _get_datetime_vec(trigger_frequency, n_time_samples, date_time, time_agg=1):
        """Prepare the temporal frequency vector given time_agg value

        Parameters
        ----------
        trigger_frequency : int
            trigger frequency of the strain data
        n_time_samples : int
            number of time steps
        date_time : datetime.datetime
            datetime (tz-aware in UTC)
        time_agg: int, default 1 (no averaging)
            bin width to take into account for averaging

        Returns
        -------
        time : np.array (floats)
            Relative time shifts in between the measurements
        datetime_vector : np.array (datetime.datetime)
            Vector with timezone aware datetime objects
        """
        assert (
            date_time.tzinfo == timezone.utc
        ), "Start time and end time should have UTC timezone (tz=timezone.utc)"

        assert time_agg >= 1, "Only downsampling supported. time_agg must be > 1"

        dt = time_agg / trigger_frequency
        if time_agg > 1:
            endpoint = True
        else:
            endpoint = False

        time = np.linspace(
            0,
            (n_time_samples / time_agg) * dt - n_time_samples % dt,
            ceil(n_time_samples / time_agg),
            endpoint=endpoint,
        )

        datetime_vector = pd.to_datetime(date_time) + pd.to_timedelta(time, unit="s")

        return time, datetime_vector

    def remove_time_zeros(self):
        """Interpolate time steps with zeros for all positions

        Updates the variable itself by converting time steps for which each position
        equals zero to nan and interpolate these nan values.

        Notes
        -----
        This does not solve the first set of zeros when a new measurement starts up,
        as the interpolation would not work. However, it does have an effect on the
        Aragon reset of denoised strain/temp data after a couple of seconds.
        """
        self.xr_data[self.variable_name] = self.xr_data[self.variable_name].where(
            abs(self.xr_data[self.variable_name]).sum(dim="position") != 0, np.nan
        )
        self.xr_data[self.variable_name] = self.xr_data[
            self.variable_name
        ].interpolate_na(dim="time")

    def _lookup_scale_factor_from_header(self):
        """Lookup calibration scale factor based on the header metadata

        Returns
        -------
        Float
            Calibration scale factor
        """

        # Get the file time from the header dict (Mac HFS+ time convention)
        file_time = pd.Timestamp(
            _handle_labview_datetime(self.bin_file.header[100], self.bin_file._filename)
        ).tz_localize(
            None
        )  # noqa

        # Load the calibration table
        stream = pkg_resources.resource_stream(
            __name__, "data/aragon_hdas_calibration_values.csv"
        )
        hdas_calibration_values = pd.read_csv(
            stream, sep=";", parse_dates=["calibration_time"]
        )

        # Select only rows in the table with the right serial number.
        hdas_calibration_values = hdas_calibration_values[
            hdas_calibration_values["laser_serial_number"]
            == self.bin_file.header_dict["LaserSN(0-1-2=195-196-197)"]
        ]

        if hdas_calibration_values.empty:
            raise LookupError(
                f"HDAS with laser serial "
                f"number {self.bin_file.header_dict['LaserSN(0-1-2=195-196-197)']} not "
                f"found in the calibration table "
                f"(pyhdas/src/data/aragon_hdas_calibration_values.csv)."
            )

        # Select only rows in the table with the date before the current date
        hdas_calibration_values = hdas_calibration_values[
            hdas_calibration_values["calibration_time"] < file_time
        ]
        # Select the most recent calibration
        hdas_calibration_values = hdas_calibration_values[
            hdas_calibration_values["calibration_time"]
            == max(hdas_calibration_values["calibration_time"])
        ]

        return hdas_calibration_values["calibration_value"].iloc[0]


def _handle_labview_datetime(header_unix_datetime, filename):
    """Manage the Labview incomging time and correct with shift if needed

    Parameters
    ----------
    header_unix_datetime : int
        Unix datetime timestamp
    filename : str | Path
        File path of the original aragon BIN file

    Notes
    -----
    In older versions (<2023) of the Aragon Labview software, a time shift of 65 years
    was introduced in the timestamp data contained in the header. Newer data provides
    correct datetime in the header. The function uses the difference between the
    year in the file name with the year in the header datetime to check for this version
    (as labview version is not part of the header afaik).
    """
    utc_timestamp = header_unix_datetime - 2082844800  # represents UTC timestamp
    utc_datetime = utc_timestamp_to_datetime(utc_timestamp)
    if int(Path(filename).name[0:4]) != utc_datetime.year:
        utc_timestamp = header_unix_datetime  # represents UTC timestamp
        utc_datetime = utc_timestamp_to_datetime(utc_timestamp)

    return utc_datetime


@Aragon.register_subclass("HDAS_2Dmap_Strain")
class AragonStrain(Aragon):
    """Represent Aragon denoised Strain data"""

    dt = np.dtype("<f8")
    variable_name = "strain"

    def __init__(self, aragon_bin, cable_range=None):
        """Load Aragon strain data

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        super(AragonStrain, self).__init__(aragon_bin, cable_range)

    def serialize(self, cable_range=None):
        """Serialize an Aragon strain .bin file to xarray DataSet"""

        # extract matrix dimensions
        # Extract temporal information and setup time coordinate vector
        trigger_frequency = self.header[6] / self.header[15] / self.header[98]
        # Trigger frequency of the strain data
        n_processed_points = int(self.header[14] - self.header[12])

        data_matrix, n_time_samples = self._parse_2d_vector(n_processed_points)

        # Extract spatial information and setup position coordinate vector
        spatial_sampling_meters = self.header[1]
        fiber_position_offset = self.header[11]
        z, z_index = get_spatial_vec(
            spatial_sampling_meters, n_processed_points, fiber_position_offset
        )

        # Labview had a specific time offset in earlier versions
        utc_datetime = _handle_labview_datetime(
            self.header[100], self.bin_file._filename
        )  # noqa
        time, datetime_das = self._get_datetime_vec(
            trigger_frequency, n_time_samples, utc_datetime
        )

        # When converting timestamps with timezone info, xarray converts
        # them to object/str
        # TODO find alternative strategy to handle this
        datetime_das = datetime_das.tz_localize(None)

        # Build the xarray object to return
        xr_data = xr.Dataset(
            {self.variable_name: (["time", "position"], data_matrix)},
            coords={
                "time": ("time", datetime_das),
                "position": ("position", z),
            },
        )

        # extract requested cable_range
        if cable_range:
            xr_data = self.slice_cable(xr_data, cable_range)

        # conversion mk to strain
        mk_to_strain = 10
        xr_data[self.variable_name] = xr_data[self.variable_name] * mk_to_strain

        # Add metadata attributes
        metadata = {
            "trigger_frequency": trigger_frequency,
            "spatial_sampling": spatial_sampling_meters,
            "fiber_position_offset": fiber_position_offset,
            "das_type": "aragon",
        }

        xr_data = xr_data.assign_attrs(metadata)
        xr_data.strain.attrs["units"] = "nanostrain"
        xr_data.position.attrs["units"] = "m"
        # add all original file header fields as such
        xr_data = xr_data.assign_attrs(self.bin_file.header_dict)
        return xr_data


@Aragon.register_subclass("HDAS_2DRawData_Strain")
class AragonRawStrain(Aragon):
    """Represent Aragon raw Strain data"""

    dt = np.dtype("<i2")
    variable_name = "rawstrain"

    def __init__(self, aragon_bin, cable_range=None):
        """Load Aragon raw strain data

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        super(AragonRawStrain, self).__init__(aragon_bin, cable_range)

    def serialize(self, cable_range=None):
        """Serialize an Aragon Raw strain .bin file to xarray DataSet"""

        # Trigger frequency of the strain data
        trigger_frequency = self.header[6] / self.header[15] / self.header[98]
        n_processed_points = int(self.header[14] - self.header[12])

        data_matrix, n_time_samples = self._parse_2d_vector(n_processed_points)

        # Extract spatial information and setup position coordinate vector
        spatial_sampling_meters = self.header[1]
        fiber_position_offset = self.header[11]
        z, z_index = get_spatial_vec(
            spatial_sampling_meters, n_processed_points, fiber_position_offset
        )

        # Labview had a specific time offset in earlier versions
        utc_datetime = _handle_labview_datetime(
            self.header[100], self.bin_file._filename
        )  # noqa
        time, datetime_das = self._get_datetime_vec(
            trigger_frequency, n_time_samples, utc_datetime
        )

        # When converting timestamps with timezone info, xarray converts
        # them to object/str
        # TODO find alternative strategy to handle this
        datetime_das = datetime_das.tz_localize(None)

        # Build the xarray object to return
        xr_data = xr.Dataset(
            {self.variable_name: (["time", "position"], data_matrix)},
            coords={
                "position": ("position", z),
                "time": ("time", datetime_das),
            },
        )

        # extract requested cable_range
        if cable_range:
            xr_data = self.slice_cable(xr_data, cable_range, ignore_ref_fiber=False)

        # mk_to_strain = 1  # no multipliation done

        # Add metadata attributes
        metadata = {
            "trigger_frequency": trigger_frequency,
            "spatial_sampling": spatial_sampling_meters,
            "fiber_position_offset": fiber_position_offset,
            "das_type": "aragon",
        }

        xr_data = xr_data.assign_attrs(metadata)
        xr_data.rawstrain.attrs["units"] = "nanostrain"
        xr_data.position.attrs["units"] = "m"
        # add all original file header fields as such
        xr_data = xr_data.assign_attrs(self.bin_file.header_dict)
        return xr_data

    def denoise(
        self,
        scale_factor="from_settings",
        demodulating=True,
        laser_denoising=True,
        laser_denoising_method="segmented",
        scaling=True,
        peak_hopping=True,
        ref_update_denoising="from_settings",
        ref_update_time_window_ms="from_settings",
        fiber_ref_start_m="from_settings",
        fiber_ref_stop_m="from_settings",
    ):
        """Get the denoised version of the raw strain data

        Adds a 'strain' DataArray to  self.xr_data (xarray Dataset) with the
        denoised version of the data

        Parameters
        ----------
        scale_factor : float
            Scaling factor as provided by Aragon Photonics. This scale factor is
            dependent on the device and resulting from the lab calibration from Aragon.
        demodulating : bool, optional
            Apply demodulation (True/False).
        laser_denoising : bool, optional
            Apply the laser denoising using the reference fiber (True) or not (False).
        laser_denoising_method : str, default "segmented"
            Either using the "segmented" approach (aka median of
            mean per segment values), the "mean" or the "median" method.
        scaling : bool, optional
            Apply the scaling from raw optical to nanostrain (True/False)
        peak_hopping : bool, optional
            Whether to apply the peak-hopping algorithm (True) or not (False).
        ref_update_denoising : str, optional
            Apply (True) the denoising of flagged items by reference updates and peak
            hopping or not (False). If "from settings" is specified, it picks
            the value from recorded settings.
        ref_update_time_window_ms : str/float, optional
            Strain reference update denoise time window, in ms.
            If "from settings" is specified, it picks the value from recorded settings.
        fiber_ref_start_m : str/float, optional
            Start of reference fiber for laser denoising, in meter.
            If "from settings" is specified, it picks the value from recorded settings.
        fiber_ref_stop_m : str/float, optional
            Start of reference fiber for laser denoising in meter.
            If "from settings" is specified, it picks the value from recorded settings.

        """
        header_dict = self.bin_file.header_dict

        if scale_factor == "from_settings":
            scale_factor = self._lookup_scale_factor_from_header()

        if ref_update_denoising == "from_settings":
            ref_update_denoising = bool(
                header_dict[
                    "Global_TimeProcessing_Strain_Reference_Update_Denoise_Use?"
                ]
            )

        if fiber_ref_start_m == "from_settings":
            fiber_ref_start_m = header_dict[
                "Global_TimeProcessing_Strain_Start_Point_Laser_Denoising_(meters)"
            ]

        fiber_ref_start = np.where(self.xr_data.position.values == fiber_ref_start_m)[
            0
        ][0]

        if fiber_ref_stop_m == "from_settings":
            fiber_ref_stop_m = header_dict[
                "Global_TimeProcessing_Strain_Stop_Point_Laser_Denoising_(meters)"
            ]

        # Aragon GUI can log file with reference fiber outsude measurement domain
        if fiber_ref_stop_m > self.xr_data.position.values.max():
            raise BinFileException(
                "Reference fiber section is outside measurement domain."
            )

        fiber_ref_stop = np.where(self.xr_data.position.values == fiber_ref_stop_m)[0][
            0
        ]

        if ref_update_time_window_ms == "from_settings":
            ref_update_time_window_ms = header_dict[
                "Global_TimeProcessing_Strain_Reference_Update_Denoise_Time_Window_(ms)"
            ]

        ref_update_window = np.int64(
            ref_update_time_window_ms
            * header_dict["Global_RAM_User_SET_Trigger_Freq"]
            / header_dict[
                "Global_TimeProcessing_Number_of_Averages_(Dynamic Processing, Strain)"
            ]
            / 1000
        )
        peak_search_window_size = (
            header_dict["Global_DigitizerData_Trace_SampleRate (GS_s)"]
            * 8
            / (1 + header_dict["Global_RAM_User_SET_Sensitivity_(Chirp_Slope)"])
        )  # peak_search_window_size = SampleRate*8/ChirpSlope

        data_2d = np.ascontiguousarray(
            self.xr_data.rawstrain.values.T.copy().astype(np.float64)
        )

        data_2d = denoise_matrix(
            data_2d,
            fiber_ref_start=fiber_ref_start,
            fiber_ref_stop=fiber_ref_stop,
            peak_search_window_size=peak_search_window_size,
            ref_update_window=ref_update_window,
            scale_factor=scale_factor,
            demodulating=demodulating,
            laser_denoising=laser_denoising,
            laser_denoising_method=laser_denoising_method,
            scaling=scaling,
            peak_hopping=peak_hopping,
            ref_update_denoising=ref_update_denoising,
        )

        self.xr_data["strain"] = (("time", "position"), data_2d.T)


@Aragon.register_subclass("HDAS_2Dmap_Temp")
class AragonTemperature(Aragon):
    """Represent Aragon denoised Temperature data"""

    dt = np.dtype("<f8")
    variable_name = "temperature"

    def __init__(self, aragon_bin, cable_range=None):
        """Load Aragon temperature data

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        super(AragonTemperature, self).__init__(aragon_bin, cable_range)

    def serialize(self, cable_range=None):
        """Serialize an Aragon Temp .bin file to xarray DataSet"""

        n_processed_points = int(self.header[31] - self.header[29])
        data_matrix, n_time_samples = self._parse_2d_vector(n_processed_points)

        # Extract spatial information and setup position coordinate vector
        fiber_position_offset = self.header[28]
        spatial_sampling_meters = self.header[1]
        z, _ = get_spatial_vec(
            spatial_sampling_meters, n_processed_points, fiber_position_offset
        )

        # Extract temporal information and setup time coordinate vector
        trigger_frequency = self.header[6] / self.header[32] / self.header[99]

        # Labview had a specific time offset in earlier versions
        utc_datetime = _handle_labview_datetime(
            self.header[100], self.bin_file._filename
        )  # noqa
        time, datetime_das = self._get_datetime_vec(
            trigger_frequency, n_time_samples, utc_datetime
        )

        # When converting timestamps with timezone info, xarray converts
        # them to object/str
        # TODO find alternative strategy to handle this
        datetime_das = datetime_das.tz_localize(None)

        # Build the xarray object to return
        xr_data = xr.Dataset(
            {self.variable_name: (["time", "position"], data_matrix)},
            coords={"position": ("position", z), "time": ("time", datetime_das)},
        )

        # extract requested cable_range
        if cable_range:
            xr_data = self.slice_cable(xr_data, cable_range)

        mk_to_strain = 10
        xr_data[self.variable_name] = xr_data[self.variable_name] * mk_to_strain

        # add metadata
        metadata = {
            "trigger_frequency": trigger_frequency,
            "spatial_sampling": spatial_sampling_meters,
            "fiber_position_offset": fiber_position_offset,
            "das_type": "aragon",
        }

        xr_data = xr_data.assign_attrs(metadata)
        xr_data.position.attrs["units"] = "m"
        xr_data.temperature.attrs["units"] = "millikelvin"

        # add all original file header fields as such
        xr_data = xr_data.assign_attrs(self.bin_file.header_dict)

        return xr_data


@Aragon.register_subclass("HDAS_2DRawData_Temp")
class AragonRawTemperature(Aragon):
    """Represent Aragon raw Temperature data"""

    dt = np.dtype("<i2")
    variable_name = "rawtemperature"

    def __init__(self, aragon_bin, cable_range=None):
        """Load Aragon raw temperature data

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        super(AragonRawTemperature, self).__init__(aragon_bin, cable_range)

    def serialize(self, cable_range=None):
        """Serialize an Aragon Raw Temp .bin file to xarray DataSet"""
        n_processed_points = int(self.header[31] - self.header[29])
        data_matrix, n_time_samples = self._parse_2d_vector(n_processed_points)

        # Extract spatial information and setup position coordinate vector
        fiber_position_offset = self.header[28]
        spatial_sampling_meters = self.header[1]
        z, _ = get_spatial_vec(
            spatial_sampling_meters, n_processed_points, fiber_position_offset
        )

        # Extract temporal information and setup time coordinate vector
        trigger_frequency = self.header[6] / self.header[32] / self.header[99]

        # Labview had a specific time offset in earlier versions
        utc_datetime = _handle_labview_datetime(
            self.header[100], self.bin_file._filename
        )  # noqa
        time, datetime_das = self._get_datetime_vec(
            trigger_frequency, n_time_samples, utc_datetime
        )

        # When converting timestamps with timezone info, xarray converts
        # them to object/str
        # TODO find alternative strategy to handle this
        datetime_das = datetime_das.tz_localize(None)

        # Build the xarray object to return
        xr_data = xr.Dataset(
            {self.variable_name: (["time", "position"], data_matrix)},
            coords={"position": ("position", z), "time": ("time", datetime_das)},
        )

        # extract requested cable_range
        if cable_range:
            xr_data = self.slice_cable(xr_data, cable_range, ignore_ref_fiber=False)

        # mk_to_strain = 1  # no multipliation done

        # add metadata
        metadata = {
            "trigger_frequency": trigger_frequency,
            "spatial_sampling": spatial_sampling_meters,
            "fiber_position_offset": fiber_position_offset,
            "das_type": "aragon",
        }

        xr_data = xr_data.assign_attrs(metadata)
        xr_data.position.attrs["units"] = "m"
        xr_data.rawtemperature.attrs["units"] = "millikelvin"

        # add all original file header fields as such
        xr_data = xr_data.assign_attrs(self.bin_file.header_dict)

        return xr_data

    def denoise(
        self,
        scale_factor="from_settings",
        demodulating=True,
        laser_denoising=True,
        laser_denoising_method="segmented",
        scaling=True,
        peak_hopping=True,
        ref_update_denoising="from_settings",
        ref_update_time_window_ms="from_settings",
        fiber_ref_start_m="from_settings",
        fiber_ref_stop_m="from_settings",
    ):
        """Get the denoised version of the raw temperature data

        Adds a 'temperature' DataArray to  self.xr_data (xarray Dataset) with the
        denoised version of the data

        Parameters
        ----------
        scale_factor : float or "from_settings"
            Scaling factor as provided by Aragon Photonics. This scale factor is
            dependent on the device and resulting from the lab calibration from Aragon.
        demodulating : bool, optional
            Apply demodulation (True/False).
        laser_denoising : bool, optional
            Apply the laser denoising using the reference fiber (True) or not (False).
        laser_denoising_method : str, default "segmented"
            Either using the "segmented" approach (aka median of
            mean per segment values), the "mean" or the "median" method.
        scaling : bool, optional
            Apply the scaling from raw optical to millikelvin (True/False)
        peak_hopping : bool, optional
            Whether to apply the peak-hopping algorithm (True) or not (False).
        ref_update_denoising : str, optional
            Apply (True) the denoising of flagged items by reference updates and peak
            hopping or not (False). If "from settings" is specified, it picks
            the value from recorded settings.
        ref_update_time_window_ms : str/float, optional
            Strain reference update denoise time window, in ms.
            If "from settings" is specified, it picks the value from recorded settings.
        fiber_ref_start_m : str/float, optional
            Start of reference fiber for laser denoising, in meter.
            If "from settings" is specified, it picks the value from recorded settings.
        fiber_ref_stop_m : str/float, optional
            Start of reference fiber for laser denoising in meter.
            If "from settings" is specified, it picks the value from recorded settings.

        """
        header_dict = self.bin_file.header_dict

        if scale_factor == "from_settings":
            scale_factor = self._lookup_scale_factor_from_header()

        if ref_update_denoising == "from_settings":
            ref_update_denoising = bool(
                header_dict["Global_TimeProcessing_Temp_Reference_Update_Denoise_Use?"]
            )

        if fiber_ref_start_m == "from_settings":
            fiber_ref_start_m = header_dict[
                "Global_TimeProcessing_Temp_Start_Point_Laser_Denoising_(meters)"
            ]

        fiber_ref_start = np.where(self.xr_data.position.values == fiber_ref_start_m)[
            0
        ][0]

        if fiber_ref_stop_m == "from_settings":
            fiber_ref_stop_m = header_dict[
                "Global_TimeProcessing_Temp_Stop_Point_Laser_Denoising_(meters)"
            ]

        # Aragon GUI can log file with reference fiber outsude measurement domain
        if fiber_ref_stop_m > self.xr_data.position.values.max():
            raise BinFileException(
                "Reference fiber section is outside measurement domain."
            )

        fiber_ref_stop = np.where(self.xr_data.position.values == fiber_ref_stop_m)[0][
            0
        ]

        if ref_update_time_window_ms == "from_settings":
            ref_update_time_window_ms = header_dict[
                "Global_TimeProcessing_Temp_Reference_"
                "Update_Denoise_Time_Window_(ms)"
            ]

        ref_update_window = np.int64(
            (
                ref_update_time_window_ms
                * header_dict["Global_RAM_User_SET_Trigger_Freq"]
                / header_dict[
                    "Global_TimeProcessing_Number_of_Averages_"
                    "(Slow-Varying, Temperature)"
                ]
                / 1000
            )
        )
        peak_search_window_size = (
            header_dict["Global_DigitizerData_Trace_SampleRate (GS_s)"]
            * 8
            / (1 + header_dict["Global_RAM_User_SET_Sensitivity_(Chirp_Slope)"])
        )  # peak_search_window_size = SampleRate*8/ChirpSlope

        data_2d = np.ascontiguousarray(
            self.xr_data.rawtemperature.values.T.copy().astype(np.float64)
        )

        data_2d = denoise_matrix(
            data_2d,
            fiber_ref_start=fiber_ref_start,
            fiber_ref_stop=fiber_ref_stop,
            peak_search_window_size=peak_search_window_size,
            ref_update_window=ref_update_window,
            scale_factor=scale_factor,
            demodulating=demodulating,
            laser_denoising=laser_denoising,
            laser_denoising_method=laser_denoising_method,
            scaling=scaling,
            peak_hopping=peak_hopping,
            ref_update_denoising=ref_update_denoising,
        )

        self.xr_data["temperature"] = (("time", "position"), data_2d.T)


@Aragon.register_subclass("HDAS_2Dmap_Energy")
class AragonEnergy(Aragon):
    """Represent Aragon energy data"""

    dt = np.dtype("<f8")
    variable_name = "energy"

    def __init__(self, aragon_bin, cable_range=None):
        """Load Aragon energy data

        Parameters
        ----------
        aragon_bin : AragonBinFile
        cable_range : tuple of int (min, max)
            Provide a cable range to extract from the data using the start and end point
            in meter.
        """
        super(AragonEnergy, self).__init__(aragon_bin, cable_range)

    def serialize(self, cable_range=None):
        """Serialize an Aragon Energy .bin file to xarray DataSet"""
        n_processed_points = int(self.header[14] - self.header[12])
        data_matrix, n_time_samples = self._parse_2d_vector(n_processed_points)

        # Extract spatial information and setup position coordinate vector
        fiber_position_offset = self.header[11]
        spatial_sampling_meters = self.header[1]
        z, _ = get_spatial_vec(
            spatial_sampling_meters, n_processed_points, fiber_position_offset
        )

        # Extract temporal information and setup time coordinate vector
        trigger_frequency = (
            1000 / self.header[24]
        )  # 1000 hardcoded -> See original script aragon

        # Labview had a specific time offset in earlier versions
        utc_datetime = _handle_labview_datetime(
            self.header[100], self.bin_file._filename
        )  # noqa
        time, datetime_das = self._get_datetime_vec(
            trigger_frequency, n_time_samples, utc_datetime
        )

        # When converting timestamps with timezone info, xarray converts
        # them to object/str
        # TODO find alternative strategy to handle this
        datetime_das = datetime_das.tz_localize(None)

        # Build the xarray object to return
        xr_data = xr.Dataset(
            {
                self.variable_name: (("time", "position"), data_matrix),
                self.variable_name
                + "_db": (
                    ("time", "position"),  # prevent zero division
                    10 * np.log10(np.where(data_matrix == 0, np.nan, data_matrix)),
                ),
            },
            coords={"position": ("position", z), "time": ("time", datetime_das)},
        )

        # extract requested cable_range
        if cable_range:
            xr_data = self.slice_cable(xr_data, cable_range)

        # mk_to_strain = 1  # no multipliation done

        # add metadata
        metadata = {
            "trigger_frequency": trigger_frequency,
            "spatial_sampling": spatial_sampling_meters,
            "fiber_position_offset": fiber_position_offset,
            "das_type": "aragon",
        }
        xr_data = xr_data.assign_attrs(metadata)
        xr_data.position.attrs["units"] = "m"
        xr_data[self.variable_name].attrs["units"] = "nanostrain^2/Hz"
        xr_data[self.variable_name + "_db"].attrs["units"] = "decibel"

        # add all original file header fields as such
        xr_data = xr_data.assign_attrs(self.bin_file.header_dict)
        return xr_data
