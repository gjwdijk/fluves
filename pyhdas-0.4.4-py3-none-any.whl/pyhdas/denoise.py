# Copyright (C) 2019 Fluves - All Rights Reserved
import importlib.util

import numpy as np

# Check if optional install 'numba' is available
package_name = "numba"
spec = importlib.util.find_spec(package_name)
if not spec:
    raise ImportError("Install 'numba' to use the Aragon functionalities")
else:
    from numba import jit


class AragonDenoiseException(Exception):
    """Error raised when denoising aragon bin files."""

    pass


@jit(nopython=True, cache=True)
def demodulate(data_2d: np.ndarray) -> (np.ndarray, np.ndarray):
    """Convert raw to strain values

    Demodulate to strain and elements are flagged in ref_updates array if there were
    reference updates (hardcoded value > 12000). To enable the numba compilation,
    the input array :code:`data_2d` input array need to be converted to float64 dtype
    already.

    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Raw values as measured by DAS, converted to float64 values

    Returns
    -------
    data_2d : np.array, float64, N position x T time steps
        Demodulated values

    Notes
    -----
    The logged value :code:`( int16 ) = Timedelay * 400 + 20000` if a reference
    update was active, :code:`( int16 ) = Timedelay * 400` otherwise. :code`Timedelay`
    is the value of interest, which is directly related to measured nanostrain and
    defines the time delay in digital samples with respect to the reference fiber
    state. The reference fiber updates are defined by values > 12000. Maximum allowed
    time delay = +/-16 digital samples (6400 in int16).
    """

    n_processed_points, n_time_samples = data_2d.shape
    strain_reference = np.zeros(n_processed_points)
    for time_idx in range(n_time_samples):
        for position_idx in range(n_processed_points):
            if data_2d[position_idx, time_idx] > 12000.0:
                variation = (data_2d[position_idx, time_idx] - 20000.0) / 400.0
                data_2d[position_idx, time_idx] = (
                    strain_reference[position_idx] + variation
                )
                strain_reference[position_idx] = (
                    strain_reference[position_idx] + variation
                )
            else:
                variation = data_2d[position_idx, time_idx] / 400.0
                data_2d[position_idx, time_idx] = (
                    strain_reference[position_idx] + variation
                )

    return data_2d


@jit(nopython=True, cache=True)
def denoise_with_reference_fiber(
    data_2d: np.ndarray,
    fiber_ref_start: int,
    fiber_ref_stop: int,
    method: str = "segmented",
) -> np.ndarray:
    """Laser denoising using reference fiber

    Denoise strain values using reference fiber values. Currently implemented methods
    are:

        * "segmented": median of segment mean (mean per segment - mean per segment
          previous time step). Number of segments equals the length of each segment.
        * "mean": subtract using the mean value of the reference fiber of the current
          time step.
        * "median": subtract using the median value of the reference fiber of the
          curren time step.


    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Demodulated measured strain values
    fiber_ref_start: int
        Index of the start position of the reference fiber. Corresponds to the
        :code:`Global_TimeProcessing_Strain_Start_Point_Laser_Denoising_(integer)`
        aragon header for strain data
    fiber_ref_stop: int
        Index of the last position of the reference fiber. Corresponds to the
        :code:`Global_TimeProcessing_Strain_Stop_Point_Laser_Denoising_(integer)`
        aragon header for strain data
    method : str, default "segmented"
        Either using the "segmented" approach (aka median of mean segment values),
        the "mean" or the "median" approach

    Returns
    -------
    data_2d : np.array, float64, N position x T time steps
        Denoised strain values

    Notes
    -----
    As the method chosen for laser denoising has no header-option, we assume the
    `auto-denoising` has been applied a which corresponds to the
    'median of mean method'.
    """
    n_processed_points, n_time_samples = data_2d.shape

    if method == "segmented":
        segment_length = int(np.floor(np.sqrt(fiber_ref_stop - fiber_ref_start + 1)))

        for time_idx in range(1, n_time_samples):
            segmented_mean = np.zeros(segment_length)
            for segment_idx in range(segment_length):
                segmented_mean[segment_idx] = np.mean(
                    data_2d[
                        fiber_ref_start
                        + segment_idx * segment_length : fiber_ref_start
                        + (segment_idx + 1) * segment_length,
                        time_idx,
                    ]
                ) - np.mean(
                    data_2d[
                        fiber_ref_start
                        + segment_idx * segment_length : fiber_ref_start
                        + (segment_idx + 1) * segment_length,
                        time_idx - 1,
                    ]
                )
            data_2d[:, time_idx] = data_2d[:, time_idx] - np.median(segmented_mean)

    elif method == "mean":
        for time_idx in range(1, n_time_samples):
            data_2d[:, time_idx] = data_2d[:, time_idx] - np.mean(
                data_2d[fiber_ref_start : fiber_ref_stop + 1, time_idx]
            )

    elif method == "median":
        for time_idx in range(1, n_time_samples):
            data_2d[:, time_idx] = data_2d[:, time_idx] - np.median(
                data_2d[fiber_ref_start : fiber_ref_stop + 1, time_idx]
                - data_2d[fiber_ref_start : fiber_ref_stop + 1, time_idx - 1]
            )
    else:
        raise AragonDenoiseException(
            "Reference fiber denoise method unknown, use either"
            "segmented, median or mean."
        )

    return data_2d


def detect_peak_hopping(
    data_2d: np.ndarray, flagged: np.ndarray, peak_search_window_size: int
) -> np.ndarray:
    """Identify and flag peak hopping

    Identify peak hopping measurements and add these as flag (True) to the flagged
    array. Both flag arrays are combined with :code:`or` statement. Peaks are
    identified if discontinuity between two values in time is larger than
    1/4 peak_search_window_size setting.

    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Demodulated (and denoised) measured strain values
    flagged : np.array, bool, N position x T time steps
        Defines whether (True) or not (False) the measurement is flagged.
    peak_search_window_size : int
        Size of the peak to identify. :code:`SampleRate*8/ChirpSlope`. Corresponds to
        :code:`Global_DigitizerData_Trace_SampleRate (GS_s) * 8 /(1 +
        Global_RAM_User_SET_Sensitivity_(Chirp_Slope))`

    Returns
    -------
    flagged : np.array, bool, N position x T time steps
        Defines whether (True) or not (False) the measurement is flagged.

    Notes
    -----
    This step only identified peaks and does not alter the :code:`data_2d` itself.
    It adds additional flags to the incoming flagged array.

    """
    peaks = (
        np.abs(np.diff(data_2d, prepend=data_2d[:, 0].reshape(-1, 1)))
        > peak_search_window_size / 4.0
    )
    return flagged | peaks


def scale_values(data_2d: np.ndarray, factor: float) -> np.ndarray:
    """Scale values according to calibration factor.

    Data after demdulation is expressed in digital samples and to be scaled to
    nanostrain (tabled value, acording to choosen settings)

    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Demodulated (and denoised) measured strain values
    factor : float
        Scaling factor as provided by Aragon Photonics. This scale factor is
        dependent on the device and resulting from the lab calibration from Aragon.

    Returns
    -------
    data_2d : np.array, float64, N position x T time steps
        Demodulated (and denoised) measured strain values with calibration
        factor applied.

    Notes
    -----
    The scaling factor is a factor obtained at Aragon Photonics when calibrating each
    HDAS system with a standard monomode fiber and kept fixed while its use.

    The current scaling factor value of a HDAS is stored on the HDAS PC under
    C -> Program Files (86) -> Aragon Photonics -> config -> config_laser.apl``.
    """
    return data_2d * 10 * factor


@jit(nopython=True, cache=True)
def denoise_flagged(data_2d: np.ndarray, flagged: np.ndarray, ref_update_window):
    """Denoise the flagged values

    For each of the flagged values in the :code:`flagged` array, the difference
    between the mean of a set of earlier values at the same position minus the mean
    of a set of later values at the same position is used to correct the
    flagged measurement.

    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Demodulated (, denoised) and rescaled measured strain values
    flagged : np.array, bool, N position x T time steps
        Defines whether (True) or not (False) the measurement is flagged.
    ref_update_window : int
        Length of the window for the back- and forward window to aggregate over.
        Corresponds to :code:`Global_TimeProcessing_Strain_Reference_Update_
        Denoise_Time_Window_(ms) * Global_RAM_User_SET_Trigger_Freq /
        Global_TimeProcessing_Number_of_Averages_(Dynamic Processing, Strain)` setting.

    Returns
    -------
    data_2d : np.array, float64, N position x T time steps
        Demodulated (and denoised) measured strain values with the flagged elements
        adjusted using the values of the neighbouring values.

    Notes
    -----
    The algorithm uses the difference in mean values of a backward and forward window
    in time to adjust the flagged measurement. The backward window:starts at time-2,
    got a minimum length of 2 samples.  The forward window starts at time+1, got a
    minimum length of 2 samples. The length is defined by :code:`ref_update_window`
    setting, but the window is shortened if there is another flagged value in the
    window (first non-zero index in flagged array).
    """
    n_processed_points, n_time_samples = data_2d.shape
    reference_updates = np.zeros(n_processed_points)

    for time_idx in range(n_time_samples):
        for position_idx in range(n_processed_points):
            if (
                flagged[position_idx, time_idx]
                and ref_update_window < time_idx < n_time_samples - ref_update_window
            ):
                # use tuple inside concatenate for numba support -
                # https://github.com/numba/numba/issues/2787
                window_start = np.nonzero(
                    np.concatenate(
                        (
                            flagged[
                                position_idx,
                                time_idx - 3 : time_idx - 1 - ref_update_window : -1,
                            ],
                            np.array([1]),
                        )
                    )
                )[0][0]
                window_stop = np.nonzero(
                    np.concatenate(
                        (
                            flagged[
                                position_idx,
                                time_idx + 2 : time_idx + ref_update_window,
                            ],
                            np.array([1]),
                        )
                    )
                )[0][0]

                reference_updates[position_idx] = np.mean(
                    data_2d[position_idx, time_idx - 3 - window_start : time_idx - 1]
                ) - np.mean(
                    data_2d[position_idx, time_idx + 1 : time_idx + 3 + window_stop]
                )
            data_2d[position_idx, time_idx] = (
                data_2d[position_idx, time_idx] + reference_updates[position_idx]
            )

    return data_2d


def denoise_matrix(
    data_2d,
    fiber_ref_start,
    fiber_ref_stop,
    peak_search_window_size,
    ref_update_window,
    scale_factor=None,
    demodulating=True,
    laser_denoising=True,
    laser_denoising_method="segmented",
    scaling=True,
    peak_hopping=True,
    ref_update_denoising=True,
):
    """Apply Aragon denoise algorithm to raw data

    For more in depth information on the individual steps, see the specific functions.

    Parameters
    ----------
    data_2d : np.array, float64, N position x T time steps
        Raw values as measured by DAS, converted to float64 values
    fiber_ref_start : int
        Index of the start position of the reference fiber. Corresponds to the
        :code:`Global_TimeProcessing_Strain_Start_Point_Laser_Denoising_(integer)`
        aragon header for strain data
    fiber_ref_stop : int
        Index of the last position of the reference fiber. Corresponds to the
        :code:`Global_TimeProcessing_Strain_Stop_Point_Laser_Denoising_(integer)`
        aragon header for strain data
    peak_search_window_size : int
        Size of the peak to identify. :code:`SampleRate*8/ChirpSlope`. Corresponds to
        :code:`Global_DigitizerData_Trace_SampleRate (GS_s) * 8 /(1 +
        Global_RAM_User_SET_Sensitivity_(Chirp_Slope))`
    ref_update_window : int
        Length of the window for the back- and forward window to aggregate over.
        Corresponds to :code:`Global_TimeProcessing_Strain_Reference_Update_
        Denoise_Time_Window_(ms) *
        Global_RAM_User_SET_Trigger_Freq / Global_TimeProcessing_Number_of_Averages_
        (Dynamic Processing, Strain)` setting.
    scale_factor : float
        Scaling factor as provided by Aragon Photonics. This scale factor is
        dependent on the device and resulting from the lab calibration from Aragon.
    demodulating : bool
        Apply demodulation True) or not (False).
    laser_denoising : bool
        Apply the laser denoising using the reference fiber (True) or not (False).
    laser_denoising_method : str, default "segmented"
        Either using the "segmented" approach (aka median of mean per segment values),
        the "mean" or the "median" method.
    scaling : bool, optional
        Apply scaling (True) or not (False).
    peak_hopping : bool, optional
        Whether to apply the peak-hopping algorithm (True) or not (False).
    ref_update_denoising
        Apply (True) the denoising of flagged items by reference updates or peak
        hopping (True) or not (False).

    Returns
    -------
    denoised_data : np.array, float64, N position x T time steps
        Denoised values using Aragon denoising algorithm.

    Notes
    -----
    As STEP 3 is only relevant when :code:`ref_update_denoising` is :code:`True`
    and does not alter the data itself (only adding flags), it is put after step 4.
    """
    if scaling and (not scale_factor):
        raise AragonDenoiseException(
            "Denoise scale factor need to be provided as "
            "input. This value is device dependent and "
            "provided by Aragon."
        )

    if ref_update_denoising:
        flagged = data_2d > 12000.0

    # STEP 1 - demodulation
    if demodulating:
        demodulated = demodulate(data_2d)
    else:
        demodulated = data_2d / 400.0

    # STEP 2 - laser denoising using reference fiber
    if laser_denoising:
        denoised_ref = denoise_with_reference_fiber(
            demodulated, fiber_ref_start, fiber_ref_stop, laser_denoising_method
        )
    else:
        denoised_ref = demodulated

    # STEP 4 - scale using calibration value
    if scaling:
        scaled_ref = scale_values(denoised_ref, scale_factor)
    else:
        scaled_ref = denoised_ref

    if ref_update_denoising:
        if peak_hopping:
            # STEP 3 - detect peak hopping occurrence
            flagged = detect_peak_hopping(
                denoised_ref, flagged, peak_search_window_size
            )
        # STEP 5 - denoise flagged values by reference update or peak hopping
        denoised_data = denoise_flagged(scaled_ref, flagged, ref_update_window)
    else:
        denoised_data = scaled_ref

    return denoised_data
