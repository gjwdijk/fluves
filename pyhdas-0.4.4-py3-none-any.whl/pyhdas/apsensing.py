# Copyright (C) 2019 Fluves - All Rights Reserved

import logging
import re

import h5py
import numpy as np
import pandas as pd
import xarray as xr

from .utils import get_spatial_vec, get_timestamp_vec

logger = logging.getLogger(__name__)


def phase_to_strain(phase, gauge_length):
    """ "strain calculation function"""
    epsilon = 0.17
    n0 = 1.4682
    p11 = 0.12
    p12 = 0.27
    scale_factor = 1 - (0.5 * n0 * n0) * (p12 - (epsilon * (p11 + p12)))
    wave_length = 1550e-9
    strain = (phase * wave_length) / (2 * 2 * np.pi * n0 * gauge_length * scale_factor)

    return strain


def _apsensing_select_files(data_folder, start_date, end_date, filetype="hdf5"):
    """Extract a subset of files in a folder based on dates

    Generator to provide apsensing type files.

    Parameters
    ----------
    data_folder : Path
        Path to folder with data
    start_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    filetype : h5 | bin
        select the original binary files or the hdf5 version
    """
    pattern = re.compile(
        r"(?<=_)[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}\.[0-9]{2}\.[0-9]{2}\.[0-9]*"
    )

    logger.info(f"Read files from {start_date} till {end_date}")

    for filename in data_folder.rglob(f"*.{filetype}"):
        if filename.name.find("Test") == -1:
            res = pattern.search(filename.name)
            date_string = res.group()
            datetime_file = pd.to_datetime(
                date_string, format="%Y-%m-%d_%H.%M.%S.%f"
            ).tz_localize("UTC")
            if start_date - pd.Timedelta(61, unit="s") <= datetime_file <= end_date:
                yield filename
            else:
                continue


def apsensing_load_data(
    data_folder, start, end, cable_range=None, calibration_factor=1.0e9
):
    """Concatenate apsensing data files to single xarray DataSet

    Look recursive through all files in a folder and extract the data,
    for the given time range (between `start` and `end`). Only extract the
    values according to the given cable range.

    Parameters
    ----------
    data_folder : Path
        Main folder to look in for data files or a single file name
    start : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    cable_range : tuple
        Range of the cable to select data from (according to m cable), e.g. (0, 200)
    calibration_factor : Float, optional
        Calibration factor to convert data to nanostrain

    """
    data = []
    all_timestamps_das = []

    if data_folder.is_file():
        file_list = [data_folder]
    else:
        file_list = sorted(_apsensing_select_files(data_folder, start, end))

    for i, filepath in enumerate(file_list):
        logger.info(f"Load file {filepath.name}...")

        with h5py.File(filepath, "r", libver="latest") as h5_file:
            if (
                "DAS" not in h5_file
            ):  # If the file doesn't contain 'DAS', it's not a time series, so skip it
                continue
            trigger_frequency = h5_file["DAQ/RepetitionFrequency"][0]
            spatial_sampling_m = h5_file["/ProcessingServer/SpatialSampling"][0]
            # trace_count = h5_file["/Metadata/TraceCount"][0]
            # points = h5_file["/DAQ/SpatialPoints"][0]
            spatial_sampling_points = h5_file[
                "/ProcessingServer/SpatialSamplingPoints"
            ][0]
            gauge_length = h5_file["/ProcessingServer/GaugeLength"][0]
            time_file = h5_file["/Metadata/Timestamp"][0]
            utc_timestamp = pd.to_datetime(time_file.decode("utf-8")).timestamp()
            position_start = h5_file["/DAQ/PositionStart"][0]
            position_end = h5_file["/DAQ/PositionEnd"][0]

        data_file = xr.open_dataset(filepath)
        data_file = data_file.rename({"phony_dim_4": "times"})
        data_file = data_file.rename({"phony_dim_5": "positions"})

        # Now define the 'real' x axis
        z, z_index = get_spatial_vec(
            spatial_sampling_m, data_file.positions.size, position_start
        )
        data_file = data_file.assign_coords({"positions": np.double(z)})

        # create the timestamp array for this data set
        times, timestamps_das = get_timestamp_vec(
            trigger_frequency, data_file.times.size, utc_timestamp
        )
        all_timestamps_das.append(np.array(timestamps_das))

        if cable_range:
            data.append(data_file.sel(positions=slice(*cable_range)))
        else:
            data.append(data_file)

    logger.info("Concatenating...")
    data = xr.concat(data, dim="times")
    all_timestamps_das = np.concatenate(all_timestamps_das)
    logger.info("... all APSensing files concatenated.")

    logger.info("Converting phase data to strain...")
    data = data.assign(phase=data["DAS"].cumsum(axis=0) * (np.pi / 2**15))
    data = data.assign(records=phase_to_strain(data["phase"], gauge_length))
    data = data.drop_vars(["DAS", "phase"])

    logger.info("Conversion complete.")

    # Build the xarray object to return
    xr_data = xr.DataArray(
        data.records.values * calibration_factor,
        coords={
            "time": ("time", all_timestamps_das),
            "position": ("position", data.positions.values),
        },
        dims=["time", "position"],
    )
    xr_data = xr_data.to_dataset(name="records")

    metadata = {
        "trigger_frequency": trigger_frequency,
        "spatial_sampling": spatial_sampling_m,
        "spatial_sampling_points": spatial_sampling_points,
        "position_start": position_start,
        "position_end": position_end,
        "das_type": "apsensing",
    }

    xr_data = xr_data.assign_attrs(metadata)

    xr_data.records.attrs["units"] = "nanostrain"
    xr_data.positions.attrs["units"] = "m"

    return xr_data
