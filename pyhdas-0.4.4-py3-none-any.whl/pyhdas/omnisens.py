# Copyright (C) 2019 Fluves - All Rights Reserved

import logging
import re

import numpy as np
import pandas as pd
import xarray as xr

from .utils import get_spatial_vec, get_timestamp_vec

logger = logging.getLogger(__name__)


def _omnisens_select_files(data_folder, start_date, end_date, datatype="strain"):
    """Extract a subset of files in a folder based on dates

    Generator providing omnisens files according to given datetime range.

    Parameters
    ----------
    data_folder : Path
        Path to folder with data, files will be collected in from all subfolders
    start_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end_date : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    datatype : str, default 'strain'
    """
    pattern = re.compile("(?<=_)[0-9]*(?=_)")

    for filename in data_folder.rglob("*.h5"):
        if datatype not in filename.name:
            continue
        res = pattern.search(filename.name)
        date_string = res.group()
        datetime_file = pd.to_datetime(date_string, format="%y%m%d%H%M%S").tz_localize(
            "UTC"
        )
        if start_date - pd.Timedelta(61, unit="s") <= datetime_file <= end_date:
            yield filename
        else:
            continue


def omnisens_load_data(
    data_folder,
    start,
    end,
    cable_range=None,
    data_type="strain",
    calibration_factor=32.8,
):
    """Concatenate omnisens data files to single xarray DataSet

    Look recursive through all files in a folder and extract the data of the
    given `data_type`, for the given time range (between `start` and `end`). Only
    extract the values according to the given cable range.

    Parameters
    ----------
    data_folder : Path
        Main folder to look in for data files or a single file name
    start : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    cable_range : tuple
        Range of the cable to select data from (according to m cable), e.g. (0, 200)
    data_type : str, default 'strain'
        Provide the type of output file, e.g. `strain` or `energy`
    calibration_factor : Float, optional
        Calibration factor to convert data to nanostrain
    """
    data = []
    all_timestamps_das = []

    if data_folder.is_file():
        file_list = [data_folder]
    else:
        file_list = sorted(
            _omnisens_select_files(data_folder, start, end, datatype=data_type)
        )

    for i, filepath in enumerate(file_list):
        logger.info(f"Load file {filepath.name}...")

        # TODO add check on similar spatial samplings
        spatial_sampling_m = xr.open_dataset(
            filepath, group="measurement"
        ).spatial_sampling_m.values

        data_file = xr.open_dataset(filepath)
        data_file = data_file.swap_dims(
            {"phony_dim_3": "distances_us", "phony_dim_4": "times"}
        )
        data_file = data_file.rename({"distances_us": "positions"})

        # Now define the 'real' x axis
        z, z_index = get_spatial_vec(
            spatial_sampling_m, data_file.positions.size, 0
        )  # offset not an option for omnisens
        data_file = data_file.assign_coords({"positions": z})

        # create the timestamp array for this data set
        trigger_frequency = int(
            xr.open_dataset(filepath, group="daq").trigger_freq.values
        )
        utc_timestamp = int(
            xr.open_dataset(filepath, group="headers").utc_timestamp.values
        )
        #   Assign the 'real' timestamp axis measured by das
        utc_timestamp = utc_timestamp / 1000000
        times, timestamps_das = get_timestamp_vec(
            trigger_frequency, data_file.times.size, utc_timestamp
        )
        all_timestamps_das.append(np.array(timestamps_das))

        if cable_range:
            data.append(data_file.sel(positions=slice(*cable_range)))
        else:
            data.append(data_file)

    logger.info("Concatenating...")
    data = xr.concat(data, dim="times")
    all_timestamps_das = np.concatenate(all_timestamps_das)

    # Build the xarray object to return
    xr_data = xr.DataArray(
        data.records.values * calibration_factor,
        coords={
            "time": ("time", all_timestamps_das),
            "position": ("position", data.positions.values),
        },
        dims=["time", "position"],
    )
    xr_data = xr_data.to_dataset(name="records")

    logger.info("... all omnisens files concatenated.")

    metadata = {
        "trigger_frequency": trigger_frequency,
        "spatial_sampling": spatial_sampling_m,
        "das_type": "omnisens",
    }

    xr_data = xr_data.assign_attrs(metadata)

    xr_data.records.attrs["units"] = "nanostrain"
    xr_data.position.attrs["units"] = "m"

    return xr_data
