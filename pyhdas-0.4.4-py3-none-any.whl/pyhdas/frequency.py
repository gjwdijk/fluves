# Copyright (C) 2019 Fluves - All Rights Reserved

import logging

import numpy as np
import pandas as pd
import xarray as xr
from scipy import signal as signal

logger = logging.getLogger(__name__)


THIRD_OCTAVE_BANDS = [
    0.244,
    0.308,
    0.388,
    0.488,
    0.615,
    0.775,
    0.977,
    1.230,
    1.550,
    1.953,
    2.461,
    3.100,
    3.906,
    4.922,
    6.201,
    7.812,
    9.843,
    12.40,
    15.625,
    19.686,
    24.80,
    31.25,
    39.37,
    49.61,
    62.50,
    78.75,
    99.21,
    125.00,
    157.49,
    198.43,
    250.00,
    314.98,
    396.85,
    500.00,
    629.96,
    793.70,
    1000.00,
    1259.92,
    1587.40,
    2000.00,
    2519.84,
    3174.80,
    4000.00,
    5039.68,
    6349.60,
    8000.00,
    10079.37,
    12699.21,
    16000.00,
    20158.74,
]  # standard 1/3-octave band frequencies, [Hz]


def _get_window_width(trigger_frequency, min_frequency):
    """Calculate the frequency width"""

    if min_frequency > trigger_frequency:
        raise ValueError(
            f"Trigger frequency {trigger_frequency} need to be "
            f"larger than minimal frequency {min_frequency}."
        )
    return int(abs(trigger_frequency / min_frequency))


def _add_time_reference(data, ref_data, time_dimension="time"):
    """Add time info from reference data set to data as new dimension

    When reducing on the 'time' dimension, the resulting time info can be translated to
    a single value dimension to the data set together with start and end attributes.
    """
    assert time_dimension in ref_data.dims, (
        f"No '{time_dimension}' dimension " f"in the reference data."
    )

    assert time_dimension not in data.dims, (
        f"Target data already contains " f"'{time_dimension}' dimension."
    )

    assert (
        ref_data[time_dimension].dtype == "datetime64[ns]"
    ), f"'{time_dimension}' is not a datetime dtype."

    datetime_start_period = ref_data[time_dimension].values[0]
    datetime_end_period = ref_data[time_dimension].values[-1]

    data = data.assign_coords({time_dimension: datetime_start_period})
    data = data.expand_dims(time_dimension)
    data = data.assign_attrs(
        start_period=str(datetime_start_period),
        end_period=str(datetime_end_period),
    )
    return data


def _dim_to_end(data, dimension):
    """Transpose a chosen dimension as last dimension and return other dims

    This utility enables the application of scipy/numpy functions on any kind of
    xarray dimension. Moving the reducing (along which the function operates) to
    the end, conforms to the default ``axis=-1`` option of numpy/scipy.

    Parameters
    ----------
    data : xr.DataSet | xr.DataArray
        Data set to transpose
    dimension : str
        Name of the dimension to use as last dimension

    Returns
    -------
    data : xr.DataSet | xr.DataArray
        Transposed version of the data
    dimensions_order : list
        List of dimension names not reduced.
    """
    assert dimension in data.dims, f"No '{dimension}' dimension in the data."

    # Restructure xarray data set to make dimension to calculate over the last one
    dimensions_order = list(data.dims)
    dimensions_order.remove(dimension)
    return data.transpose(*dimensions_order, dimension), dimensions_order


def _check_freq_inputs(data, variable, dimension, new_dimension):
    """Support function to check inputs on frequency conversion functions"""
    assert new_dimension not in data.dims.keys(), (
        f"{new_dimension} is already dimension of the xarray DataSet, "
        f"choose a different name for new dimension."
    )

    assert variable in data.data_vars, (
        f"{variable} is not a data variable "
        f"of the xarray DataSet. "
        f"Use one of {set(data.data_vars)} as 'variable'"
    )

    assert dimension in data.dims, (
        f"{dimension} is not a dimension "
        f"of the xarray DataSet. "
        f"Use one of {set(data.dims)} as 'dimension'."
    )


def power_spectrum(
    data,
    trigger_frequency=None,
    min_frequency=1,
    variable="strain",
    dimension="time",
    sample_freq_name="freq",
    keep_time_dim=False,
):
    """Calculate the power spectrum

    Parameters
    ----------
    data : xarray 2-D Dataset
        DAS data set for a set of given locations (multiple position element)
    trigger_frequency : int
        Trigger frequency of the incoming data
    min_frequency : int
        Minimum frequency that can be seen
    variable : str, default 'strain'
        For older configurations, 'records' was used
    dimension : str, default 'time'
        Dimension of the xarray DataSet to calculate the spectrum
    sample_freq_name : str, default 'freq'
        Name of the newly created sample frequencies dimension.
    keep_time_dim : bool
        If True, the dime dimension in the data is kept as a single value dimension
        in the resulting power spectrum DataSet.

    Returns
    -------
    ps_data : xarray
        Power spectrum data

    Examples
    --------
    >>> # example data set: strain data, 5 position, 200 time steps, fs 10
    >>> data_set = xr.Dataset(
    ...                 {"strain": (["position", "time"],
    ...                 np.random.random(1000).reshape(5, 200))},
    ...                 coords={"position": ("position", np.arange(5)),
    ...                         "time": ("time", np.arange(200))},
    ...                 attrs={"trigger_frequency": 10}
    ...             )
    >>> # get power spectrum (Pxx & Pxx_dB) for each position using default settings
    >>> ps = power_spectrum(data_set)
    >>> # get spectrum of a spectrum for each position
    >>> power_spectrum(ps, trigger_frequency=2, variable="Pxx",
    ...                dimension="freq", sample_freq_name="mod")
    """
    _check_freq_inputs(data, variable, dimension, sample_freq_name)

    if not trigger_frequency:
        assert "trigger_frequency" in data.attrs, (
            "Data does not contain "
            "trigger_frequency attribute,"
            "provide trigger_frequency."
        )
        trigger_frequency = data.attrs["trigger_frequency"]

    data, dimensions_order = _dim_to_end(data, dimension)

    window_width = _get_window_width(trigger_frequency, min_frequency)
    f, pxx = signal.welch(
        data[variable],
        fs=trigger_frequency,
        nperseg=window_width,
        detrend="linear",
        axis=-1,  # default is last axis
    )

    logger.debug(f"Minimum frequency that can be observed is {f[1]} Hz.")

    # update the set of data coordinates
    coords = {
        key: value for (key, value) in data.coords.items() if key in dimensions_order
    }
    coords[sample_freq_name] = f

    ps_data = xr.Dataset(
        {
            "Pxx": ((*dimensions_order, sample_freq_name), pxx),
        },
        coords,
    )

    ps_data = add_db(
        ps_data,
        variable="Pxx",
        interpolate_zeros=True,
        interpolate_dim=sample_freq_name,
    )

    ps_data[sample_freq_name].attrs["units"] = "Hz"

    # backward compatible addition - (position is not anymore required as dimension)
    if "position" in dimensions_order:
        ps_data.position.attrs["units"] = "m"

    # keep time info when reducing along a datetime dimension
    if keep_time_dim:
        ps_data = _add_time_reference(ps_data, data, time_dimension=dimension)

    return ps_data


def spectrogram(
    data,
    trigger_frequency=None,
    min_frequency=0.5,
    variable="strain",
    dimension="time",
    sample_freq_name="freq",
    mode="psd",
):
    """Calculate the spectrogram

    Parameters
    ----------
    data : xarray.DataSet
        HDAS data set with strain data
    trigger_frequency : None | int
        Trigger frequency of the incoming data. If None, the DataSet attribute
        trigger_frequency is used (if existing)
    min_frequency : int
        Minimum frequency that can be seen
    variable : str, default 'strain'
        Name of the variable to take spectrogram. For older configurations,
        'records' was used as strain.
    dimension : str, default 'time'
        Name of the time dimension of the xarray DataSet to calculate spectrogram.
    sample_freq_name : str, default 'freq'
        Name of the newly created sample frequencies dimension.
    mode : (‘psd’, ‘complex’, ‘magnitude’, ‘angle’, ‘phase’), default 'psd'
        Default the power spectral density ('psd'). ‘complex’ is equivalent to the
        output of stft with no padding or boundary extension. ‘magnitude’ returns the
        absolute magnitude of the STFT. ‘angle’ and ‘phase’ return the complex angle
        of the STFT, with and without unwrapping, respectively.

    Returns
    -------
    spectrogram_data : xarray
        Spectrogram data

    Notes
    -----
    When calculating the spectrogram, n_overlap is set to half of the window.
    When using a min_freq of 0.5, calculating a 60-second bin file with a sample
    width of 1s gives 59 spectra wiht a 1 second resolution.

    Examples
    --------
    >>> # example data set: strain data, 5 position, 200 time steps, fs 10
    >>> t_vec = pd.to_datetime("2020-05-01 00:00:00") + pd.to_timedelta(
    ...                                        np.arange(0, 200/10, 0.1), unit="s")
    >>> data_set = xr.Dataset(
    ...                 {"strain": (["position", "time"],
    ...                 np.random.random(1000).reshape(5, 200))},
    ...                 coords={"position": ("position", np.arange(5)),
    ...                         "time": ("time", t_vec)},
    ...                 attrs={"trigger_frequency": 10}
    ...             )
    >>> # get spectrogram (Pxx & Pxx_dB) for each position using default settings
    >>> ps = spectrogram(data_set)
    >>> # get angle ('angle') for each position using default settings
    >>> ps = spectrogram(data_set, mode="angle")
    """
    _check_freq_inputs(data, variable, dimension, sample_freq_name)

    if not trigger_frequency:
        assert "trigger_frequency" in data.attrs, (
            "Data does not contain "
            "trigger_frequency attribute,"
            "provide trigger_frequency."
        )
        trigger_frequency = data.attrs["trigger_frequency"]

    # time dimension need to be a datetime
    assert (
        data[dimension].dtype == "datetime64[ns]"
    ), f"'{dimension}' dimension is not a datetime dtype."

    data, dimensions_order = _dim_to_end(data, dimension)

    window_width = _get_window_width(trigger_frequency, min_frequency)
    if data[dimension].shape[0] < window_width:
        raise ValueError("Data length smaller than one spectrogram window width.")

    f, t, pxx = signal.spectrogram(
        data[variable],
        fs=trigger_frequency,
        nperseg=window_width,
        noverlap=window_width // 2,
        detrend="linear",
        axis=-1,
        mode=mode,
    )

    if f.size > 1:
        logger.debug(f"Minimum frequency that can be observed is {f[1]} Hz.")
    else:
        logger.warning(
            "Only frequency that can be observed is O Hz, "
            "the mean value of your signal"
        )
    logger.debug(f"Spectrogram sample width is {window_width}.")

    # update the set of data coordinates
    coords = {
        key: value for (key, value) in data.coords.items() if key in dimensions_order
    }
    coords[sample_freq_name] = f
    coords[dimension] = data[dimension].values[0] + pd.to_timedelta(t, "s")

    # backward compatibility - adjustment of the returned variable
    if mode in ["complex", "magnitude", "angle", "phase"]:
        variable_name = mode
    elif mode == "psd":
        variable_name = "Pxx"

    spectrogram_data = xr.Dataset(
        {
            variable_name: ((*dimensions_order, sample_freq_name, dimension), pxx),
        },
        coords,
    )

    if mode == "psd":
        spectrogram_data = add_db(
            spectrogram_data,
            variable="Pxx",
            interpolate_zeros=True,
            interpolate_dim=sample_freq_name,
        )

    spectrogram_data[sample_freq_name].attrs["units"] = "Hz"
    # backward compatible addition - (position is not anymore required as dimension)
    if "position" in dimensions_order:
        spectrogram_data.position.attrs["units"] = "m"

    # add original attributes to spectrogram
    spectrogram_data = spectrogram_data.assign_attrs(data.attrs)

    return spectrogram_data


def third_octave_spectrogram(xr_spectrogram, freqs_per_band=1):
    """Converting spectrogram data frame to 1/3-octave bands data frame

    Parameters
    ----------
    xr_spectrogram : xarray spectrogram dataset
        Spectrogram dataset generated with utils.spectrogram
    freqs_per_band : int, optional
        Minimum number of frequencies for a valid band

    Returns
    -------
    xarray
        Spectrogram in third-octave bins
    """
    bands = np.array(THIRD_OCTAVE_BANDS)
    band_widths_no_scale = 2 ** (1 / 6) - 2 ** (-1 / 6)
    band_widths = bands * band_widths_no_scale

    # calculating minimum and maximum frequency
    # from input spectrogram array
    min_freq = xr_spectrogram.freq[xr_spectrogram.freq > 0].min().values
    max_freq = xr_spectrogram.freq.max().values

    # selecting bands based on limits
    selected_bands = bands[
        np.logical_and(
            # freqs_per_band > 1 for sum of multiple frequencies in a band
            band_widths >= freqs_per_band * min_freq,
            bands <= max_freq,
        )
    ]

    # band limits from low and high filter frequencies
    band_lim = list(np.array(selected_bands) * 2 ** (-1 / 6)) + [
        selected_bands[-1] * 2 ** (1 / 6)
    ]

    xr_spectrogram = xr_spectrogram.drop_vars("Pxx_dB")
    spect_group = xr_spectrogram.groupby_bins("freq", band_lim)
    spect_third = spect_group.sum()
    spect_third = spect_third.assign_coords({"freq": ("freq_bins", selected_bands)})
    spect_third = spect_third.swap_dims({"freq_bins": "freq"})
    spect_third["Pxx_dB"] = 10 * (np.log10(spect_third["Pxx"]) + np.log10(min_freq))
    spect_third["Pxx_dB_disp"] = (
        spect_third["Pxx_dB"]
        - 10 * np.log10(spect_third.freq)
        - 10 * np.log10(band_widths_no_scale)
    )
    spect_third = spect_third.assign_attrs(xr_spectrogram.attrs)

    return spect_third


def energy(
    data,
    trigger_frequency=None,
    min_frequency=1,
    frequency_range=(300, 500),
    variable="strain",
):
    """Calculate energy plot

    Parameters
    ----------
    data : xarray 2-D Dataset
        Strain DAS data set with `strain` as the strain data for
        slice of locations (position) and time steps (time).
    trigger_frequency : int
        Trigger frequency of the incoming data
    min_frequency : int
        Minimum frequency that can be seen
    frequency_range : slice(int, int)
        Minimum and maximum frequency to do integration
    variable : str, default 'strain'
        For older configurations, 'records' was used

    Returns
    -------
    energy_data : xarray
        Energy data
    """

    spec = spectrogram(
        data,
        trigger_frequency=trigger_frequency,
        min_frequency=min_frequency,
        variable=variable,
    )

    energy_data = spec.sel(freq=slice(*frequency_range)).integrate("freq")

    energy_data = add_db(energy_data)

    return energy_data


def high_pass_filter(
    data,
    variable="strain",
    trigger_frequency=None,
    cutoff=5,
    filter_order=5,
    dimension="time",
):
    """Apply high pass filter to time series

    Parameters
    ----------
    data : xarray Dataset
        DAS Dataset for a given location
    variable : str, optional
        Variable to perform the high-passing on (default = "strain")
    trigger_frequency : int
        Trigger frequency of the incoming data
    cutoff : int
        Filter cut-off
    filter_order : int
        Order of the Butterworth filter. Default = 5.
    dimension : str
        Name of the axis over which the filtering should take place. Default = "time"

    Returns
    -------
    xarray Dataset
        Dataset with high-passed data in data["variable_hp"], e.g. data["strain_hp"]
    """

    if not trigger_frequency:
        trigger_frequency = data.attrs["trigger_frequency"]

    cutoff = cutoff  # Cutoff frequency
    fs = trigger_frequency  # Sampling Frequency
    nyq = fs / 2  # Nyquist Frequency

    b, a = signal.butter(filter_order, cutoff / nyq, btype="high", analog=False)

    def filter_func(x):
        return signal.filtfilt(
            b, a, x, padtype=None, axis=data[variable].get_axis_num(dimension)
        )

    # Add the high-passed filtered as an additional variable in the dataset
    data[f"{variable}_hp"] = xr.apply_ufunc(filter_func, data[variable])

    return data


def add_db(data, variable="Pxx", interpolate_zeros=False, interpolate_dim="freq"):
    """Add dB version of a data variable to xarray DataSet

    Parameters
    ----------
    data : xarray.dataset
        Input dataset to add dB
    variable : str, optional
        Variable to add the dB scale to (default = "Pxx")
    interpolate_zeros : bool, optional
        If true, zero values are replaced by an interpolated value, to avoid nan in the
        log10 calculation (default = False)
    interpolate_dim : str, optional
        Dimension along which to interpolate the zero values (default = "freq")

    Returns
    -------
    xarray.dataset
        Dataset including _dB variable
    """

    data_temp = data.copy()

    if interpolate_zeros:
        data_temp[variable] = (
            data_temp[variable]
            .where(data_temp[variable] != 0)
            .interpolate_na(
                dim=interpolate_dim
            )  # This does linear interpolation, but does not extrapolate to
            # first and last point
            .interpolate_na(
                dim=interpolate_dim, method="nearest", fill_value="extrapolate"
            )  # This does nearest-neighbour extrapolation for the boundary points
            # (can't use linear extrapolation since that might give negative values)
        )

    data[f"{variable}_dB"] = 10 * np.log10(data_temp[variable])
    return data


def reverse_db(data, variable="Pxx"):
    """Add non-dB version of a data variable to xarray DataSet

    Parameters
    ----------
    data : xarray.dataset
        Input dataset to remove dB from
    variable : str, optional
        Variable to remove the dB scale from (default = "Pxx")

    Returns
    -------
    xarray.dataset
        Dataset including non-_dB variable
    """

    data[variable] = 10 ** (data[f"{variable}_dB"] / 10.0)
    return data


def moving_average_hanning(data, width=41, variable="Pxx", dim="freq"):
    """Hanning-window moving average of an xarray, e.g. to band-average a spectrum

    Parameters
    ----------
    data : xr.dataset
        Input dataset
    width : int, optional
        Window width of the hanning window (should be an odd number). Default = 41
    variable : str, optional
        Variable to run the smoothing over (default = "Pxx")
    dim : str, optional
        Dimension over which to run the moving average (default = "freq")

    Returns
    -------
    xr.dataset
        Dataset including the smoothed variable ("variable_smooth")
    """
    # Construct window
    weight_array = np.hanning(width)
    weight_array = weight_array / sum(weight_array)
    weight = xr.DataArray(weight_array, dims=["window"])

    # Convolve spectrogram with window
    data[variable + "_smooth"] = (
        data[variable]
        .rolling({dim: width}, center=True, min_periods=1)
        .construct("window")
        .dot(weight)
    )
    data = data.assign_coords(dim=data[dim])

    return data


def moving_median(data, width=21, variable="Pxx", dim="freq"):
    """Moving median of an xarray, e.g. to remove sharp peaks

    Parameters
    ----------
    data : xr.dataset
        Input dataset
    width : int, optional
        Window width of the moving median
    variable : str, optional
        Variable to run the smoothing over (default = "Pxx")
    dim : str, optional
        Dimension over which to run the moving average (default = "freq")

    Returns
    -------
    xr.dataset
        Dataset including the smoothed variable ("variable_median")
    """
    # Convolve spectrogram with window
    data[variable + "_median"] = (
        data[variable].rolling({dim: width}, center=True, min_periods=1).median()
    )
    data = data.assign_coords(dim=data[dim])

    return data


def filter_spatial_frequencies(
    spec,
    analysis_zone,
    filter_zone,
    peak_width_upper_limit_hz=3,
    prominence_lower_limit=10,
    averaging_operator="mean",
    filter_width_hz=3,
    input_variable_no_db="Pxx",
    output_variable_no_db="Pxx_spatial_filtered",
):
    """Filter out certain frequency peaks that are consistent in space, such as laser
    noise or pump station noise

    WARNING: This function was fully developed and tested for DALI, but in the end it
    was decided not to use this functionality. The function is included here for
    posteriority, but is no longer maintained or tested.

    Parameters
    ----------
    spec : xr.Dataset
        Spatial spectrogram with dimensions position and frequency
    analysis_zone : tuple
        Start and end of zone that is used to find the relevant frequency peaks,
        i.e. a region where the peaks are clearly detectable
    filter_zone : tuple
        Start and end of the zone where the frequency peaks should be filtered out
    peak_width_upper_limit_hz : int, optional
        Upper limit for the frequency peak width, in Hz. By default 3
    prominence_lower_limit : int, optional
        Lower limit for the frequency peak prominence. By default 10
    averaging_operator : str, optional
        Either "mean" or "median" (by default "mean"), the operator used to create the
        analysis spectrum used to detect the peaks
    filter_width_hz : float
        Width in Hz of the zone that should be filtered out. For example, if
        filter_width_hz=5, then the band
        (peak_frequency - filter_width_hz <-> peak_frequency + filter_width_hz)
        will be removed from the source spectrogram and replaced by linear
        interpolation. Default = 3
    input_variable_no_db : str
        Name of variable to be filtered, default = Pxx
    output_variable_no_db : str
        Name of the output variable, default = Pxx_spatial_filtered

    Returns
    -------
    spec_filt: xr.Dataset
        Dataset with the spatially consistent frequency peaks filtered out
    spec_analysis: xr.Dataset
        Dataset with the analysis spectrum, used to detect the peaks
    prop_table: pd.Dataframe
        Table with the properties of each peak
    """
    # Define the analysis spectrum as the "average" (mean or median) spectrum
    # of the analysis zone

    input_variable_db = input_variable_no_db + "_dB"
    output_variable_db = output_variable_no_db + "_dB"

    if input_variable_db not in spec.data_vars:
        spec = add_db(spec, variable=input_variable_no_db)

    if averaging_operator == "mean":
        spec_analysis = (
            add_db(spec.sel(position=slice(*analysis_zone)).mean(dim="position"))
            .squeeze()
            .load()
        )
    elif averaging_operator == "median":
        spec_analysis = (
            add_db(spec.sel(position=slice(*analysis_zone)).median(dim="position"))
            .squeeze()
            .load()
        )
    else:
        logger.error(
            f"Averaging operator {averaging_operator} not supported."
            f'Currently supported are "mean" and "median".'
        )

    delta_f = (
        spec_analysis.freq[1:3].diff(dim="freq").values[0]
    )  # Resolution of spectrum

    # Find peaks
    peak_width_upper_limit_samples = peak_width_upper_limit_hz / delta_f

    peaks, props = signal.find_peaks(
        spec_analysis[input_variable_db].values,
        prominence=prominence_lower_limit,
        width=(None, peak_width_upper_limit_samples),
        rel_height=0.5,
        wlen=40,
    )

    # Remove peaks in the very first few points of the spectrum
    points_to_clear = 3
    for item, key in props.items():
        props[item] = [y for (x, y) in zip(peaks, key) if x > points_to_clear]
    peaks = [x for x in peaks if x > points_to_clear]

    # Add some extra properties to the props dictionary:
    # The frequency of each peak in Hz
    props["freq"] = spec_analysis.isel(freq=peaks).freq.values
    # The base level to which each peak prominence is calculated
    props["base_level"] = (
        spec_analysis[input_variable_db].isel(freq=peaks).values - props["prominences"]
    )

    nan_width_samples = int(filter_width_hz / delta_f)

    # Nan out the values near the peaks for the analysis spectrum - only for plotting
    # purposes
    spec_analysis_filter = spec_analysis.copy(deep=True)
    spec_analysis_filter = spec_analysis_filter.assign(
        {output_variable_db: spec_analysis_filter[input_variable_db]}
    )
    logger.debug(
        f"Filtering peaks at : {' Hz, '.join([str(x) for x in props['freq']])} Hz."
    )
    for my_peak in peaks:
        spec_analysis_filter[output_variable_db].loc[
            {
                "freq": spec_analysis_filter.freq[
                    (
                        spec_analysis_filter.freq
                        >= spec_analysis_filter.freq.isel(
                            freq=my_peak - nan_width_samples
                        ).values
                    )
                    & (
                        spec_analysis_filter.freq
                        <= spec_analysis_filter.freq.isel(
                            freq=my_peak + nan_width_samples
                        ).values
                    )
                ]
            }
        ] = np.nan
    spec_analysis_filter[output_variable_db] = spec_analysis_filter[
        output_variable_db
    ].interpolate_na(dim="freq")

    # filter the full spatial spectrum
    spec_filt = spec.copy(deep=True)
    spec_filt = spec_filt.assign({output_variable_db: spec_filt[input_variable_db]})
    for my_peak in peaks:
        spec_filt[output_variable_db].loc[
            {
                "freq": spec_filt.freq[
                    (
                        spec_filt.freq
                        >= spec_filt.freq.isel(freq=my_peak - nan_width_samples).values
                    )
                    & (
                        spec_filt.freq
                        <= spec_filt.freq.isel(freq=my_peak + nan_width_samples).values
                    )
                ],
                "position": spec_filt.position[
                    (spec_filt.position >= filter_zone[0])
                    & (spec_filt.position <= filter_zone[1])
                ],
            }
        ] = np.nan
    spec_filt[output_variable_db] = spec_filt[output_variable_db].interpolate_na(
        dim="freq"
    )

    spec_filt = reverse_db(spec_filt, variable=output_variable_no_db)
    spec_analysis_filter = reverse_db(
        spec_analysis_filter, variable=output_variable_no_db
    )

    # Only spec_filt is necessary for processing pipeline, rest is for plotting/checking
    # purposes
    return spec_filt, spec_analysis, spec_analysis_filter, peaks, props
