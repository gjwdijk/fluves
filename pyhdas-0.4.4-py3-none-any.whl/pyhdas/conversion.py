# Copyright (C) 2019 Fluves - All Rights Reserved

import logging
from collections import Counter
from functools import partial
from multiprocessing import Pool
from pathlib import Path

from .aragon import Aragon, AragonBinFile, aragon_select_files
from .frequency import spectrogram, third_octave_spectrogram

logger = logging.getLogger(__name__)


def extract_hourly(data_folder, start, end, chunk_size=5, extension="bin"):
    """Extract the N first available files for each hour

    For each hour where ``>= n_files`` files are available, the iterator
    returns a set of ``n_files`` as a chunk in between the start and end period
    of the files in a given ``data_folder``.

    Parameters
    ----------
    data_folder : pathlib.Path
        Main folder to look for data files
    start : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    chunk_size :
        Number of files to yield as a single chunk
    extension : h5 | bin
        Select the original binary files or the hdf5 version
    """
    files = list(aragon_select_files(data_folder, start, end, extension=extension))
    file_names = [file.stem for file in files]
    files_per_hour = Counter([file[:13] for file in file_names])
    for date_hour, n_files in files_per_hour.items():
        if n_files >= chunk_size:
            files_of_this_hour = [file for file in files if date_hour in file.stem]
            yield files_of_this_hour[:chunk_size]


def aragon_bin_to_third_octave(input_bin_file):
    """Converts an aragon Bin file to xarray h5 third octave band files

    Parameters
    ----------
    input_bin_file : Path
        Input file path
    """

    # Load the Bin file
    with AragonBinFile(input_bin_file) as bin_file:
        aragon = Aragon.load(bin_file)

    # TODO -> if class raw -> add denoise step
    # aragon.denoise()
    # print("Done denoising, moving on to spectrogram.")
    # Convert to spectogram
    spect = spectrogram(aragon.xr_data)

    if not spect:  # If the input file was too short, spectrogram returns None
        return None

    # Convert to third octave bands
    # TODO - generalize to multiple kind of bands
    third_oct = third_octave_spectrogram(spect, freqs_per_band=1)
    return third_oct


def _convert_aragon_wrapper(
    filename,
    delete_bin=False,
    output_folder=None,
    skip_existing=True,
    min_file_size=0.0,
):
    """Wrapper for Aragon bin to h5 conversion

    Parameters
    ----------
    filename : Path (Pathlib module)
        File pathlib of the Aragon data file
    delete_bin : bool, optional
        Whether to delete the bin files after converting them. (default=False)
    output_folder : Path (Pathlib module), optional
        Output folder where the h5 file is written
    skip_existing : bool, optional
        Skip existing converted files (default=True)
    min_file_size : float, optional
        Minimum file size to convert, in MB

    Returns
    -------
    TYPE
        Description
    """

    # Make filename of new output file
    if output_folder is None:
        output_folder = filename.parent

    third_octave_filename = (
        filename.with_suffix(".h5")
        .name.replace("HDAS_2Dmap", "HDAS_Thirdospect")
        .replace("HDAS_2DRawData", "HDAS_Thirdospect")
    )
    new_file = output_folder / third_octave_filename

    # Check if output file exists
    if skip_existing:
        if new_file.exists():
            # logger.info(f"{third_octave_filename} already exists. Skipping...")
            return

    # Now perform conversion
    logger.info(f"Converting {filename.name}.")
    conversion_successful = True
    try:
        third_octave = aragon_bin_to_third_octave(filename)
        if not third_octave:
            logger.warning(f"Conversion of  {filename.name} unsuccessful.")
            return
        logger.info("Conversion successful.")
    except AssertionError:
        logger.warning(f"Conversion of  {filename.name} unsuccessful.")
        return
    except ValueError:
        logger.warning(
            f"Conversion of  {filename.name} unsuccessful, "
            f"probably due to NaNs in the input data."
        )
        return

    third_octave.freq_bins.values = third_octave.freq_bins.values.astype(str)

    # Save to h5
    third_octave.to_netcdf(new_file)

    if not new_file.exists():
        conversion_successful = False
        logger.warning(f"Saving {filename.name} after conversion unsuccessful.")
    else:
        logger.info(f"Saving {filename.name} after conversion successful.")

    if delete_bin and conversion_successful:
        filename.unlink()


def aragon_file_convert(
    inputfolder,
    cores=4,
    delete_bin=False,
    file_pattern="",
    output_folder=None,
    skip_existing=True,
    min_file_size=0.0,
):
    """Convert al HDAS_2Dmap_Strain files recursively in a
    folder and add them to data file

    Parameters
    ----------
    inputfolder : Pathlib.path
        Input folder containing the bin files
    cores : int, optional
        Number of cores to use (default = 4)
    delete_bin : bool, optional
        Whether to delete the bin files after converting them. (default=False)
    file_pattern : str, optional
        File pattern to match for conversion
    output_folder : Pathlib.path
        Output folder where h5 files are written to
    skip_existing : bool, optional
        Skip existing converted files (default=True)
    min_file_size : float, optional
        Minimum file size to convert, in MB
    """

    data_folder = Path(inputfolder)

    if output_folder is None:
        output_folder = data_folder
    else:
        output_folder = Path(output_folder)

    file_list = data_folder.rglob(file_pattern + "*.bin")
    file_list = [
        x for x in file_list if x.stat().st_size > (min_file_size * 1024 * 1024)
    ]

    with Pool(cores) as p:
        p.map(
            partial(
                _convert_aragon_wrapper,
                delete_bin=delete_bin,
                output_folder=output_folder,
                skip_existing=skip_existing,
            ),
            file_list,
        )
