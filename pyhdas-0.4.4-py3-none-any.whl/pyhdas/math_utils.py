# Copyright (C) 2019 Fluves - All Rights Reserved

import numpy as np


def power_law(x, a, b, c):
    """Power law function

    Parameters
    ----------
    x : number | np.ndarray
        independent variable
    a, b, c : number | array
        parameters

    Returns
    -------
    y : number | np.ndarray
        dependent variable
    """
    y = a * (x**b) + c
    return y


def exponential_law(x, a, b, c):
    """Exponential law function

    Parameters
    ----------
    x : number | np.ndarray
        independent variable
    a, b, c : number | array
        parameters

    Returns
    -------
    y : number | np.ndarray
        dependent variable
    """
    y = a * np.exp(b * x) + c
    return y


def nash_sutcliffe(y, y_fit):
    """Calculate the Nash-Sutcliffe fitting criterion

    The NS criterion returns a value with negative: bad, 0: fit as good as taking
    the average spectrum value, 1: perfect fit

    Parameters
    ----------
    y : np.ndarray
        observed data
    y_fit : np.ndarray
        fitted data

    Returns
    -------
    nash_sutcliffe : array
    """
    ssr_eg = ((y_fit - y) ** 2).sum()
    sst = ((y - y.mean()) ** 2).sum()
    nash_sut = 1 - ssr_eg / sst
    return nash_sut
