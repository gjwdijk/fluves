# Copyright (C) 2019 Fluves - All Rights Reserved

import datetime
import logging
import re
from itertools import compress, cycle, tee, zip_longest
from pathlib import Path

import numpy as np
import pandas as pd
import pytz

from .frequency import energy as ener
from .frequency import high_pass_filter as hpsf
from .frequency import power_spectrum as pwsp
from .frequency import spectrogram as spgr
from .frequency import third_octave_spectrogram as thoct

logger = logging.getLogger(__name__)


class InvalidFilenameException(Exception):
    """Raised when an invalid filename is encountered"""


def utc_timestamp_to_datetime(utc_timestamp):
    """Small conversion function for convenience

    Recommended approach
    https://docs.python.org/3/library/datetime.html?
        highlight=pytz#datetime.datetime.utcfromtimestamp
    """
    return datetime.datetime.fromtimestamp(utc_timestamp, datetime.timezone.utc)


def get_spatial_vec(
    spatial_sampling_meters, n_processed_points, spatial_offset=0, spatial_agg=1
):
    """Prepare the spatial frequency vector given spatial_agg value

    Parameters
    ----------
    spatial_sampling_meters : int
        every XX meters strain/temp is measured; We have a geo-phone every XX meters
    n_processed_points : int
        number of processed points (i.e. rows in the 2D data)
    spatial_offset : int
        Offset to take into account when defining spatial vector
    spatial_agg: int, default 1 (no averaging)
        bin width to take into account for averaging
    """
    dz = spatial_sampling_meters * spatial_agg
    z = np.arange(0, (n_processed_points / spatial_agg) * dz, dz) + spatial_offset
    z_index = np.arange(0, n_processed_points, 1)

    return z, z_index


def get_timestamp_vec(trigger_frequency, n_time_samples, timestamp, time_agg=1):
    """Prepare the temporal frequency vector given time_agg value

    Parameters
    ----------
    trigger_frequency : int
        trigger frequency of the strain data
    n_time_samples : int
        number of time steps (i.e. columns in the 2D data)
    timestamp : utc timestamp (int)
        Time stamp of the starting point
    time_agg: int, default 1 (no averaging)
        bin width to take into account for averaging
    """
    dt = time_agg / trigger_frequency
    time = np.arange(0, (n_time_samples / time_agg) * dt, dt)

    start_datetime = datetime.datetime.utcfromtimestamp(timestamp)
    timestamps = pd.to_datetime(start_datetime) + pd.to_timedelta(time, unit="s")

    return time, timestamps


def _get_spatial_freq_vec(spatial_sampling_meters, n_processed_points, spatial_agg=1):
    """Prepare the spatial frequency vector given spatial_agg value

    Parameters
    ----------
    spatial_sampling_meters : int
        every XX meters strain/temp is measured; We have a geo-phone every XX meters
    n_processed_points : int
        number of processed points (i.e. rows in the 2D data)
    spatial_agg: int, default 1 (no averaging)
        bin width to take into account for averaging
    """
    dz = spatial_sampling_meters * spatial_agg
    z = np.arange(0, (n_processed_points / spatial_agg) * dz, dz)
    fz_max = 1 / dz
    fz_aux = np.linspace(-fz_max / 2, fz_max / 2, z.size + 1)
    fz = fz_aux[:-1]
    dfz = fz[1] - fz[0]
    return z, fz, dfz


def _get_time_freq_vec(trigger_frequency, n_time_samples, time_agg=1):
    """Prepare the temporal frequency vector given time_agg value

    Parameters
    ----------
    trigger_frequency : int
        trigger frequency of the strain data
    n_time_samples : int
        number of time steps (i.e. columns in the 2D data)
    time_agg: int, default 1 (no averaging)
        bin width to take into account for averaging
    """
    dt = time_agg / trigger_frequency
    time = np.arange(0, (n_time_samples / time_agg) * dt, dt)
    ft_max = trigger_frequency * time_agg
    ft_aux = np.linspace(-ft_max / 2, ft_max / 2, time.size + 1)
    ft = ft_aux[:-1]
    dft = ft[1] - ft[0]
    return time, ft, dft


def _get_timestamp_from_diff(time_array):
    """Convert array of timestamps to datetime

    The function assumes the unix timestamp is in local time.

    Parameter
    ---------
    time_array : np.array (1D)
       Array with timestamps

    Returns
    -------
    datetime_array : np.array
       Array of the same size
    """
    first_timestamp = datetime.datetime.fromtimestamp(time_array[0])
    datetime_array = first_timestamp + pd.to_timedelta(
        np.cumsum(time_array[1:] - time_array[:-1]), unit="s"
    )
    datetime_array = np.insert(datetime_array, 0, [first_timestamp])
    return datetime_array


# --------------------------------------------
# BACKWARD COMPATIBILITY FREQUENCY FUNCTIONS
# --------------------------------------------


def power_spectrum(*args, **kwargs):
    """Backward compatible power spectrum"""
    logger.warning(
        "Function 'power_spectrum' moved to frequency module. "
        "Use 'frequency.power_spectrum' instead. The function will be "
        "removed from the utils module in future releases."
    )
    return pwsp(*args, **kwargs)


def spectrogram(*args, **kwargs):
    """Backward compatible spectrogram"""
    logger.warning(
        "Function 'spectrogram' moved to frequency module. "
        "Use 'frequency.spectrogram' instead. The function will be "
        "removed from the utils module in future releases."
    )
    return spgr(*args, **kwargs)


def third_octave_spectrogram(*args, **kwargs):
    """Backward compatible third octave"""
    logger.warning(
        "Function 'third_octave_spectrogram' moved to frequency module. "
        "Use 'frequency.third_octave_spectrogram' instead. The function "
        "will be removed from the utils module in future releases."
    )
    return thoct(*args, **kwargs)


def energy(*args, **kwargs):
    """Backward compatible energy"""
    logger.warning(
        "Function 'energy' moved to frequency module. "
        "Use 'frequency.energy' instead. The function will be "
        "removed from the utils module in future releases."
    )
    return ener(*args, **kwargs)


def high_pass_filter(*args, **kwargs):
    """Backward compatible high-pass"""
    logger.warning(
        "Function 'high_pass_filter' moved to frequency module. "
        "Use 'frequency.high_pass_filter' instead. The function will be "
        "removed from the utils module in future releases."
    )
    return hpsf(*args, **kwargs)


def datetime_type_file(filename):
    """Gets the datetime and type from a HDAS bin filename

    Parameters
    ----------
    filename : str
        filename without path

    Returns
    -------

    dt : datetime.datetime
    hdas_type : str
        string with data type, eg HDAS_2dRawData_Strain
    extension : str
        filename extension, bin or h5

    Raises
    ------
    InvalidFilenameException
        thrown when the file is not a HDAS bin file (based on filename)


    Examples
    -------

    >>> datetime_type_file('~/testdata/2020_07_28_06h02m23s_HDAS_2DRawData_Strain.bin')
    (datetime.datetime(2020, 7, 28, 6, 2, 23), 'HDAS_2DRawData_Strain')
    """

    if isinstance(filename, Path):
        filename = filename.name

    match_file = re.compile(
        r"(\d{4})_(\d{2})_(\d{2})_(\d{2})h(\d{2})m(\d{2})s_(.*).(bin|h5)"
    )
    check = re.search(match_file, filename)

    if check is None:
        raise InvalidFilenameException(filename)

    dt = datetime.datetime(
        int(check.group(1)),
        int(check.group(2)),
        int(check.group(3)),
        int(check.group(4)),
        int(check.group(5)),
        int(check.group(6)),
        tzinfo=pytz.UTC,
    )
    hdas_type = check.group(7)

    ext = check.group(8)

    return dt, hdas_type, ext


def group_extractor(iterable, n_elements, m_skips):
    """Collect data into N-length chunks excluding M groups in between

    The function takes an iterator and returns an iterator which collects the input
    iterators in chunks of ``n_elements``, each time skipping ``m_skips`` groups.

    Parameters
    ----------
    iterable : iterator
        Iterator yielding stream of elements
    n_elements : int
        The number of elements to collect in a single chunk
    m_skips : int
        The number of chunks to skip before yielding a new chunks

    Examples
    --------
    >>> example_set = np.arange(10)
    >>> print(example_set)
    array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    >>> print(list(group_extractor(example_set, 2, 3)))
    [(0, 1), (8, 9)]
    >>> print(list(group_extractor(example_set, 3, 1)))
    [(0, 1, 2), (6, 7, 8)]
    >>> print(list(group_extractor(example_set, 4, 1)))
    [(0, 1, 2, 3), (8, 9, None, None)]
    """
    args = [iter(iterable)] * n_elements
    return compress(zip_longest(*args), cycle([1] + m_skips * [0]))


def pairwise(iterable):
    """Loop pairwise over iterable

    The function takes an iterator and returns an iterator which collects the input
    iterators in pairwise s -> (s0,s1), (s1,s2), (s2, s3), ...

    Parameters
    ----------
    iterable : iterator
        Iterator yielding stream of elements

    See also
    --------
    This recipe is adjusted from the itertools Python documentation, using the
    ``zip_longest`` to make sure the last interval is included as well

    Examples
    --------
    >>> example_set = np.arange(10)
    >>> print(example_set)
    array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    >>> print(list(pairwise(example_set)))
    [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (7, 8), (8, 9)]
    """
    a, b = tee(iterable)
    next(b, None)
    return zip_longest(a, b)
