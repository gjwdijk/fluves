# Copyright (C) 2019 Fluves - All Rights Reserved

import numpy as np
import xarray as xr

from .frequency import _add_time_reference, _check_freq_inputs, _dim_to_end


def quantile(
    data,
    quantiles: list,
    dimension: str = "time",
    variable: str = "Pxx",
    quantile_dim_name: str = "quant",
    keep_time_dim: bool = False,
    interpolation="lower",
):
    """Take quantiles along given dimension for >= 2D xarray data

    Parameters
    ----------
    data : xr.Dataset
        xarray Dataset on for which quantiles need to be calculated
        on a given dimension.
    quantiles : list
        List of quantiles to calculate, each values between 0 and 1.
    dimension : str
        Dimension of the xarray Array/DataSet to calculate the quantile.
    variable : str, default 'Pxx'
        Name of the variable to apply quantiles.
    keep_time_dim : bool
        If True, the dime dimension in the data is kept as a single value dimension
        in the resulting power spectrum DataSet.
    quantile_dim_name : str, default quant
        Name of the newly created quantiles dimension.
    interpolation : {'linear', 'lower', 'higher', 'midpoint', 'nearest'}
        The interpolation method to use when the desired quantile lies between
        two data points. Default 'lower' (see notes).

    Returns
    -------
    data_quantiles : xr.Dataset
        Xarray dataSet of the chosen variable with a

    Notes
    -----
    The function wraps the numpy quantile, but processes the function on 2D slices at
    a time to speed up the calculation. The interpolation method is default set to
    'lower' as this provides consistent results in between quantile(log10(data))
    versus log10(quantile(data)).

    Examples
    --------
    >>> # example data set: strain data, 5 position, 200 time steps, fs 10
    >>> t_vec = pd.to_datetime("2020-05-01 00:00:00") + pd.to_timedelta(
    ...                                        np.arange(0, 200/10, 0.1), unit="s")
    >>> data_set = xr.Dataset(
    ...                 {"strain": (["position", "time"],
    ...                 np.random.random(1000).reshape(5, 200))},
    ...                 coords={"position": ("position", np.arange(5)),
    ...                         "time": ("time", t_vec)},
    ...                 attrs={"trigger_frequency": 10}
    ...             )
    >>> # Calculate a specific quantile
    >>> quantile(data_set, quantiles=[0.1], variable="strain")
    >>> # Calculate multiple quantiles at once
    >>> quantile(data_set, quantiles=[0.1, 0.25], variable="strain")
    """

    if len(data.dims) <= 1:
        raise IndexError(
            "das quantile function only supports >=2D arrays, use"
            "xr.quantile function instead."
        )

    _check_freq_inputs(data, variable, dimension, quantile_dim_name)

    data, dimensions_order = _dim_to_end(data, dimension)
    array_quantiles = xr.apply_ufunc(
        np.quantile,
        data[variable],
        vectorize=True,
        input_core_dims=[[dimensions_order[-1], dimension]],
        output_core_dims=[[quantile_dim_name, dimensions_order[-1]]],
        output_sizes={quantile_dim_name: len(quantiles)},
        kwargs={"q": quantiles, "axis": -1, "interpolation": interpolation},
        output_dtypes=["d"],
    )

    # update the set of data coordinates
    coords = {
        key: value for (key, value) in data.coords.items() if key in dimensions_order
    }
    coords[quantile_dim_name] = quantiles

    data_quantiles = xr.Dataset(
        {
            variable: (
                (*dimensions_order[:-1], quantile_dim_name, dimensions_order[-1]),
                array_quantiles.data,
            ),
        },
        coords,
    )

    data_quantiles = data_quantiles.transpose(quantile_dim_name, ...)

    # add original attributes to spectrogram
    data_quantiles = data_quantiles.assign_attrs(data.attrs)

    # keep time info when reducing along a datetime dimension
    if keep_time_dim:
        data_quantiles = _add_time_reference(
            data_quantiles, data, time_dimension=dimension
        )

    return data_quantiles
