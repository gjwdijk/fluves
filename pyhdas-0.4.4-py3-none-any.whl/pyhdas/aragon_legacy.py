# Copyright (C) 2019 Fluves - All Rights Reserved

import logging
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr

from .conversion import aragon_select_files
from .utils import get_spatial_vec as _get_spatial_vec
from .utils import get_timestamp_vec as _get_timestamp_vec

logger = logging.getLogger(__name__)

# Header 102 (ID 101) defines the file type of aragon
file_type_mapping = {
    0: "HDAS_2DRawData_Strain",
    1: "HDAS_2DRawData_Temp",
    2: "HDAS_2Dmap_Strain",
    3: "HDAS_2Dmap_Temp",
    4: "HDAS_FiberTrace",
    5: "HDAS_MultiPointStrain",
    6: "HDAS_MultiPointTemp",
    7: "HDAS_LaserRef_Strain",
    8: "HDAS_LaserRef_Temp",
    11: "HDAS_2Dmap_Energy",
}


def aragon_load_h5_data(
    data_folder, start=None, end=None, cable_range=None, calibration_factor=1.0
):
    """Concatenate aragon hdf5 converted data files to single xarray DataSet

    Look recursive through all files in a folder and extract the data of the given
    `data_type`, for the given time range (between `start` and `end`). Only extract
    the values according to the given cable range.

    Parameters
    ----------
    data_folder : Path
        Main folder to look in for data files or a single file name
    start : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    end : pd.Timestamp, datetime.datetime or str
        Datetime or string in format YYYY-mm-dd HH:MM, e.g. 2019-11-19 00:00 (UTC)
    cable_range : tuple
        Range of the cable to select data from (according to m cable), e.g. (0, 200)
    calibration_factor : Float, optional
        Calibration factor to convert data to nanostrain

    Deleted Parameters
    ------------------
    data_type : str, default 'strain'
        Provide the type of output file, e.g. `strain` or `energy`

    Returns
    -------
    xarray
        DAS data
    """
    data = []
    all_timestamps_das = []

    if isinstance(start, str):
        start = pd.Timestamp(start).tz_localize("UTC")
    if isinstance(end, str):
        end = pd.Timestamp(end).tz_localize("UTC")

    if isinstance(data_folder, list):
        file_list = data_folder
    elif isinstance(data_folder, Path) and data_folder.is_file():
        file_list = [data_folder]
    else:
        file_list = sorted(aragon_select_files(data_folder, start, end, extension="h5"))

    for i, filepath in enumerate(file_list):
        logger.info(f"Load file {filepath.name}...")

        # TODO add check on similar spatial samplings and fiber position
        spatial_sampling_m = int(
            xr.open_dataset(
                filepath, group="measurement", engine="netcdf4"
            ).spatial_sampling_m.values,
        )
        fiber_position_offset = int(
            xr.open_dataset(
                filepath, group="strain", engine="netcdf4"
            ).fiber_position_offset.values
        )

        trigger_frequency = int(
            xr.open_dataset(filepath, group="daq", engine="netcdf4").trigger_freq.values
        )
        utc_timestamp = int(
            xr.open_dataset(
                filepath, group="headers", engine="netcdf4"
            ).utc_timestamp.values
        )

        data_file = xr.open_dataset(filepath, engine="netcdf4")
        data_file = data_file.swap_dims(
            {"phony_dim_2": "positions", "phony_dim_3": "times"}
        )

        # Now define the 'real' x axis
        z, z_index = _get_spatial_vec(
            spatial_sampling_m, data_file.positions.size, fiber_position_offset
        )
        data_file = data_file.assign_coords({"positions": z})

        # create the timestamp array for this data set
        times, timestamps_das = _get_timestamp_vec(
            trigger_frequency, data_file.times.size, utc_timestamp
        )
        all_timestamps_das.append(np.array(timestamps_das))

        if cable_range:
            data.append(data_file.sel(positions=slice(*cable_range)))
        else:
            data.append(data_file)

    logger.info("Concatenating...")
    data = xr.concat(data, dim="times")
    all_timestamps_das = np.concatenate(all_timestamps_das)

    # Build the xarray object to return
    xr_data = xr.DataArray(
        data.records.transpose("times", "positions").values * calibration_factor,
        coords={
            "time": ("time", all_timestamps_das),
            "position": ("position", data.positions.values),
        },
        dims=["time", "position"],
    )
    xr_data = xr_data.to_dataset(name="strain")

    logger.info("... all aragon files concatenated.")

    metadata = {
        "trigger_frequency": trigger_frequency,
        "spatial_sampling": spatial_sampling_m,
        "das_type": "aragon",
    }

    xr_data = xr_data.assign_attrs(metadata)

    xr_data.strain.attrs["units"] = "nanostrain"
    xr_data.position.attrs["units"] = "m"

    return xr_data
